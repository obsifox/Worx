<?php
/**
 * Worx inline SVG icon store.
 *
 * Google Material icon path data, inlined - no icon fonts, no woff2 files,
 * no CDN requests. Renders at 0 external cost and works fully offline.
 *
 * @package Worx
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'worx_icon' ) ) {
	/**
	 * Return an inline SVG for a known icon name.
	 *
	 * @param string $name  Icon key (see the map below).
	 * @param int    $size  Square size in px.
	 * @param string $class Extra CSS classes.
	 * @return string SVG markup ('' for unknown names).
	 */
	function worx_icon( $name, $size = 20, $class = '' ) {
		static $paths = array(
			'check'         => 'M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z',
			'check_circle'  => 'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z',
			'info'          => 'M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z',
			'bolt'          => 'M7 2v11h3v9l7-12h-4l4-8z',
			'security'      => 'M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4zm-2 16l-4-4 1.41-1.41L10 14.17l6.59-6.59L18 9l-8 8z',
			'settings'      => 'M19.14 12.94c.04-.3.06-.61.06-.94 0-.32-.02-.64-.07-.94l2.03-1.58c.18-.14.23-.41.12-.61l-1.92-3.32c-.12-.22-.37-.29-.59-.22l-2.39.96c-.5-.38-1.03-.7-1.62-.94l-.36-2.54c-.04-.24-.24-.41-.48-.41h-3.84c-.24 0-.43.17-.47.41l-.36 2.54c-.59.24-1.13.57-1.62.94l-2.39-.96c-.22-.08-.47 0-.59.22L2.74 8.87c-.12.21-.08.47.12.61l2.03 1.58c-.05.3-.09.63-.09.94s.02.64.07.94l-2.03 1.58c-.18.14-.23.41-.12.61l1.92 3.32c.12.22.37.29.59.22l2.39-.96c.5.38 1.03.7 1.62.94l.36 2.54c.05.24.24.41.48.41h3.84c.24 0 .44-.17.47-.41l.36-2.54c.59-.24 1.13-.56 1.62-.94l2.39.96c.22.08.47 0 .59-.22l1.92-3.32c.12-.22.07-.47-.12-.61l-2.01-1.58zM12 15.6c-1.98 0-3.6-1.62-3.6-3.6s1.62-3.6 3.6-3.6 3.6 1.62 3.6 3.6-1.62 3.6-3.6 3.6z',
			'refresh'       => 'M17.65 6.35C16.2 4.9 14.21 4 12 4c-4.42 0-7.99 3.58-7.99 8s3.57 8 7.99 8c3.73 0 6.84-2.55 7.73-6h-2.08c-.82 2.33-3.04 4-5.65 4-3.31 0-6-2.69-6-6s2.69-6 6-6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z',
			'trash'         => 'M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z',
			'image'         => 'M21 19V5c0-1.1-.9-2-2-2H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2zM8.5 13.5l2.5 3.01L14.5 12l4.5 6H5l3.5-4.5z',
			'photo_library' => 'M22 16V4c0-1.1-.9-2-2-2H8c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2zm-11-4l2.03 2.71L16 11l4 5H8l3-4zM2 6v14c0 1.1.9 2 2 2h14v-2H4V6H2z',
			'compress'      => 'M10 22v-6h4v6h5v-8h5L12 3 3 14h5v8z',
			'water_drop'    => 'M12 2c-5.33 4.55-8 8.48-8 11.8 0 4.98 3.8 8.2 8 8.2s8-3.22 8-8.2c0-3.32-2.67-7.25-8-11.8zm0 18c-3.35 0-6-2.57-6-6.2 0-2.34 1.95-5.44 6-9.14 4.05 3.7 6 6.79 6 9.14 0 3.63-2.65 6.2-6 6.2z',
			'chevron'       => 'M10 6L8.59 7.41 13.17 12l-4.58 4.59L10 18l6-6z',
			// SaaS Media System additions:
			'search'        => 'M15.5 14h-.79l-.28-.27A6.471 6.471 0 0 0 16 9.5 6.5 6.5 0 1 0 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z',
			'upload'        => 'M9 16h6v-6h4l-7-7-7 7h4zm-4 2h14v2H5z',
			'download'      => 'M19 9h-4V3H9v6H5l7 7 7-7zM5 18v2h14v-2H5z',
			'close'         => 'M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z',
			'grid'          => 'M4 11h5V5H4v6zm0 7h5v-6H4v6zm6 0h5v-6h-5v6zm6 0h5v-6h-5v6zm-6-7h5V5h-5v6zm6-6v6h5V5h-5z',
			'list'          => 'M4 14h4v-4H4v4zm0 5h4v-4H4v4zM4 9h4V5H4v4zm5 5h12v-4H9v4zm0 5h12v-4H9v4zM9 5v4h12V5H9z',
			'filter'        => 'M10 18h4v-2h-4v2zM3 6v2h18V6H3zm3 7h12v-2H6v2z',
			'video'         => 'M17 10.5V7c0-.55-.45-1-1-1H4c-.55 0-1 .45-1 1v10c0 .55.45 1 1 1h12c.55 0 1-.45 1-1v-3.5l4 4v-11l-4 4z',
			'document'      => 'M14 2H6c-1.1 0-1.99.9-1.99 2L4 20c0 1.1.89 2 1.99 2H18c1.1 0 2-.9 2-2V8l-6-6zm2 16H8v-2h8v2zm0-4H8v-2h8v2zm-3-5V3.5L18.5 9H13z',
			'arrow_forward' => 'M12 4l-1.41 1.41L16.17 11H4v2h12.17l-5.58 5.59L12 20l8-8z',
		);

		$size = max( 8, (int) $size );
		$class = $class ? ' ' . esc_attr( $class ) : '';

		if ( 'logo' === $name ) {
			// Built-in neon graphic W logo (pure vector, in source).
			return '<svg xmlns="http://www.w3.org/2000/svg" class="wx-icon' . $class . '" width="' . $size . '" height="' . $size . '" viewBox="0 0 64 64" aria-hidden="true">'
				. '<defs><linearGradient id="wxGradLogo" x1="0" y1="0" x2="1" y2="1">'
				. '<stop offset="0%" stop-color="#00E5FF"/><stop offset="100%" stop-color="#8B5CF6"/>'
				. '</linearGradient></defs>'
				. '<rect x="2" y="2" width="60" height="60" rx="15" fill="#0C1019" stroke="rgba(99,102,241,0.5)" stroke-width="2"/>'
				. '<path d="M12 18 L23 48 L32 29 L41 48 L52 18" fill="none" stroke="url(#wxGradLogo)" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/>'
				. '</svg>';
		}

		if ( ! isset( $paths[ $name ] ) ) {
			return '';
		}

		return '<svg xmlns="http://www.w3.org/2000/svg" class="wx-icon' . $class . '" width="' . $size . '" height="' . $size . '" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">'
			. '<path d="' . $paths[ $name ] . '"/>'
			. '</svg>';
	}
}

if ( ! function_exists( 'worx_type_badge' ) ) {
	/**
	 * Return a compact Worx-branded file type indicator badge.
	 *
	 * @param string $mime  MIME type (e.g. 'image/webp', 'image/jpeg', 'video/mp4', 'application/pdf').
	 * @param string $ext   File extension.
	 * @return string HTML badge string.
	 */
	function worx_type_badge( $mime, $ext = '' ) {
		$type_code = 'WX IMG';
		$color_cls = 'wx-type-img';

		if ( 'image/webp' === $mime || 'webp' === $ext ) {
			$type_code = 'WX WEBP';
			$color_cls = 'wx-type-webp';
		} elseif ( 0 === strpos( $mime, 'video/' ) || in_array( $ext, array( 'mp4', 'mov', 'webm' ), true ) ) {
			$type_code = 'WX VIDEO';
			$color_cls = 'wx-type-video';
		} elseif ( 'image/svg+xml' === $mime || 'svg' === $ext ) {
			$type_code = 'WX SVG';
			$color_cls = 'wx-type-svg';
		} elseif ( 0 === strpos( $mime, 'application/' ) || in_array( $ext, array( 'pdf', 'doc', 'docx', 'zip' ), true ) ) {
			$type_code = 'WX DOC';
			$color_cls = 'wx-type-doc';
		}

		return '<span class="wx-type-pill ' . $color_cls . '">'
			. worx_icon( 'logo', 12 )
			. '<span class="wx-type-text">' . esc_html( $type_code ) . '</span>'
			. '</span>';
	}
}
