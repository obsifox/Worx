/* Worx Media Hub & Media Cards Enhancer - Vanilla JS, zero bloat. */
(function () {
	'use strict';
	var cfg = window.worxHub || {};
	var ajaxUrl = cfg.ajaxUrl || '';
	var nonce = cfg.nonce || '';
	var logoSvg = cfg.logoSvg || '';
	var i18n = cfg.i18n || {
		working: 'Processing...',
		done: 'Done',
		error: 'Error'
	};

	// 1. AJAX Reprocess handler in List View
	document.addEventListener('click', function (e) {
		var btn = e.target.closest ? e.target.closest('[data-worx-reprocess]') : null;
		if (!btn || btn.classList.contains('is-busy')) { return; }

		var id = btn.getAttribute('data-worx-reprocess');
		if (!id) { return; }

		var cell = btn.closest('.wx-hub-cell');
		var status = cell ? cell.querySelector('.wx-hub-status') : null;

		btn.classList.add('is-busy');
		if (status) {
			status.textContent = i18n.working;
			status.classList.remove('is-error');
		}

		var data = new URLSearchParams();
		data.append('action', 'worx_reprocess_image');
		data.append('nonce', nonce);
		data.append('attachment_id', id);

		fetch(ajaxUrl, {
			method: 'POST',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
			body: data.toString()
		})
		.then(function (res) { return res.json(); })
		.then(function (res) {
			btn.classList.remove('is-busy');
			if (res && res.success && res.data && res.data.html) {
				var parser = new DOMParser();
				var doc = parser.parseFromString(res.data.html, 'text/html');
				var fresh = doc.querySelector('.wx-hub-cell');
				if (fresh && cell) {
					cell.parentNode.replaceChild(fresh, cell);
				}
			} else {
				if (status) {
					status.textContent = (res && res.data && res.data.message) || i18n.error;
					status.classList.add('is-error');
				}
			}
		})
		.catch(function () {
			btn.classList.remove('is-busy');
			if (status) {
				status.textContent = i18n.error;
				status.classList.add('is-error');
			}
		});
	});

	// 2. Decorate Media Cards in Grid View with Worx Logo Badge
	function decorateCards() {
		var attachments = document.querySelectorAll('.attachments-browser .attachments .attachment:not([data-worx-decorated])');
		for (var i = 0; i < attachments.length; i++) {
			var att = attachments[i];
			att.setAttribute('data-worx-decorated', '1');

			var badge = document.createElement('span');
			badge.className = 'wx-card-badge';
			badge.innerHTML = (logoSvg ? logoSvg : '') + '<span class="wx-card-badge-label">Worx</span>';
			att.appendChild(badge);
		}
	}

	// Observer for dynamically loaded media items
	if (window.MutationObserver) {
		var observer = new MutationObserver(function () {
			decorateCards();
		});
		observer.observe(document.body, { childList: true, subtree: true });
	}

	// Run once DOM is ready
	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', decorateCards);
	} else {
		decorateCards();
	}
})();
