/**
 * Worx Media Hub — Modern SaaS Client Controller.
 * Zero external dependencies, pure Vanilla JS.
 *
 * @package Worx
 */

(function () {
	'use strict';

	if (typeof window.worxHub === 'undefined') {
		return;
	}

	const config = window.worxHub;

	// State
	const state = {
		media: [],
		selectedIds: new Set(),
		activeItem: null,
		filter: 'all',
		sort: 'newest',
		search: '',
		viewMode: 'grid',
		page: 1,
		totalPages: 1,
		isLoading: false
	};

	document.addEventListener('DOMContentLoaded', init);

	function init() {
		// Initialize Hub screen if present
		const hubWrap = document.getElementById('worx-media-system');
		if (hubWrap) {
			initMediaHub();
		}

		// Initialize modals (Custom WM & Bulk)
		initCustomWatermarkModal();
		initBulkOptimizerModal();

		// Handle legacy list row buttons on standard upload.php
		initLegacyRowButtons();
	}

	/* ==========================================================================
	   1. Worx Media Hub Workspace Controller
	   ========================================================================== */
	function initMediaHub() {
		const grid = document.getElementById('wx-hub-grid');
		const searchInput = document.getElementById('wx-hub-search-input');
		const searchClear = document.getElementById('wx-hub-search-clear');
		const filterChips = document.querySelectorAll('.wx-filter-chips .wx-chip');
		const sortSelect = document.getElementById('wx-hub-sort');
		const viewBtns = document.querySelectorAll('.wx-view-btn');
		const openUploadBtn = document.getElementById('wx-hub-open-upload');
		const emptyUploadBtn = document.querySelector('.wx-btn-empty-upload');

		// View mode toggle
		viewBtns.forEach(btn => {
			btn.addEventListener('click', () => {
				viewBtns.forEach(b => b.classList.remove('is-active'));
				btn.classList.add('is-active');
				state.viewMode = btn.dataset.mode;
				if (state.viewMode === 'list') {
					grid.classList.add('is-list');
				} else {
					grid.classList.remove('is-list');
				}
			});
		});

		// Filters
		filterChips.forEach(chip => {
			chip.addEventListener('click', () => {
				filterChips.forEach(c => c.classList.remove('is-active'));
				chip.classList.add('is-active');
				state.filter = chip.dataset.filter;
				state.page = 1;
				fetchMedia();
			});
		});

		// Sorting
		if (sortSelect) {
			sortSelect.addEventListener('change', () => {
				state.sort = sortSelect.value;
				state.page = 1;
				fetchMedia();
			});
		}

		// Instant Search with debounce
		let searchTimer = null;
		if (searchInput) {
			searchInput.addEventListener('input', () => {
				const val = searchInput.value.trim();
				if (searchClear) {
					searchClear.style.display = val ? 'block' : 'none';
				}
				clearTimeout(searchTimer);
				searchTimer = setTimeout(() => {
					state.search = val;
					state.page = 1;
					fetchMedia();
				}, 260);
			});
		}

		if (searchClear) {
			searchClear.addEventListener('click', () => {
				searchInput.value = '';
				searchClear.style.display = 'none';
				state.search = '';
				state.page = 1;
				fetchMedia();
			});
		}

		// Upload Modal
		if (openUploadBtn) {
			openUploadBtn.addEventListener('click', openUploadModal);
		}
		if (emptyUploadBtn) {
			emptyUploadBtn.addEventListener('click', openUploadModal);
		}
		initUploadModal();

		// Inspector Drawer
		initInspectorDrawer();

		// Bulk Action Bar
		initBulkActionBar();

		// Initial load
		fetchMedia();
	}

	function fetchMedia() {
		const grid = document.getElementById('wx-hub-grid');
		const emptyState = document.getElementById('wx-hub-empty');
		if (!grid) return;

		state.isLoading = true;
		grid.innerHTML = `
			<div class="wx-hub-loading">
				<span class="wx-hub-spinner"></span>
				<span>${config.i18n.working}</span>
			</div>
		`;
		if (emptyState) emptyState.style.display = 'none';

		const fd = new FormData();
		fd.append('action', 'worx_get_hub_media');
		fd.append('nonce', config.nonce);
		fd.append('search', state.search);
		fd.append('filter', state.filter);
		fd.append('sort', state.sort);
		fd.append('paged', state.page);

		fetch(config.ajaxUrl, { method: 'POST', body: fd })
			.then(r => r.json())
			.then(res => {
				state.isLoading = false;
				if (!res.success || !res.data.items.length) {
					grid.innerHTML = '';
					if (emptyState) emptyState.style.display = 'flex';
					state.media = [];
					return;
				}

				state.media = res.data.items;
				state.totalPages = res.data.max_pages;
				renderCards(res.data.items);
			})
			.catch(err => {
				state.isLoading = false;
				grid.innerHTML = `<div class="wx-hub-loading"><span style="color:#ef4444;">${config.i18n.error}</span></div>`;
			});
	}

	function renderCards(items) {
		const grid = document.getElementById('wx-hub-grid');
		const emptyState = document.getElementById('wx-hub-empty');
		if (!grid) return;

		grid.innerHTML = '';
		if (emptyState) emptyState.style.display = 'none';

		items.forEach(item => {
			const card = document.createElement('div');
			card.className = 'wx-card';
			card.dataset.id = item.id;
			if (state.selectedIds.has(item.id)) {
				card.classList.add('is-selected');
			}

			// Preview content
			let previewHtml = '';
			if (item.is_image) {
				previewHtml = `<img src="${item.thumb}" alt="${escapeHtml(item.title)}" class="wx-card-thumb" loading="lazy">`;
			} else {
				previewHtml = `
					<div class="wx-card-doc-preview">
						<span class="wx-doc-icon">${item.type_badge}</span>
						<span>${escapeHtml(item.ext)}</span>
					</div>
				`;
			}

			// Savings / status pill
			let pillHtml = '';
			if (item.needs_manual_wm) {
				pillHtml = `<span class="wx-pill-pending">${config.i18n.pendingWatermark || 'Pending Watermark'}</span>`;
			} else if (item.is_optimized) {
				pillHtml = `<span class="wx-pill-savings">-${Math.round(item.savings_percent)}%</span>`;
			}

			card.innerHTML = `
				<div class="wx-card-select">
					<input type="checkbox" class="wx-card-check" ${state.selectedIds.has(item.id) ? 'checked' : ''} aria-label="Select">
				</div>
				<div class="wx-card-badge-pos">
					${item.type_badge}
				</div>
				<div class="wx-card-preview">
					${previewHtml}
				</div>
				<div class="wx-card-body">
					<div class="wx-card-name" title="${escapeHtml(item.title)}">${escapeHtml(item.title)}</div>
					<div class="wx-card-meta">
						<span>${item.size_formatted}</span>
						${pillHtml}
					</div>
				</div>
			`;

			// Event listeners
			const checkbox = card.querySelector('.wx-card-check');
			checkbox.addEventListener('click', (e) => {
				e.stopPropagation();
				toggleSelection(item.id, checkbox.checked);
			});

			card.addEventListener('click', (e) => {
				if (e.target.closest('.wx-card-select')) return;
				openInspector(item);
			});

			grid.appendChild(card);
		});
	}

	function toggleSelection(id, isSelected) {
		if (isSelected) {
			state.selectedIds.add(id);
		} else {
			state.selectedIds.delete(id);
		}

		// Update card style
		const card = document.querySelector(`.wx-card[data-id="${id}"]`);
		if (card) {
			card.classList.toggle('is-selected', isSelected);
		}

		updateBulkBar();
	}

	function updateBulkBar() {
		const bar = document.getElementById('wx-hub-bulk-bar');
		const countEl = document.getElementById('wx-bulk-selected-count');
		const labelEl = document.getElementById('wx-bulk-selected-label');
		if (!bar || !countEl) return;

		const count = state.selectedIds.size;
		countEl.textContent = count;
		if (labelEl && config.i18n.selected) {
			labelEl.textContent = config.i18n.selected;
		}

		if (count > 0) {
			bar.style.display = 'flex';
		} else {
			bar.style.display = 'none';
		}
	}

	/* ==========================================================================
	   2. Slide-out Inspector Drawer
	   ========================================================================== */
	function initInspectorDrawer() {
		const inspector = document.getElementById('wx-hub-inspector');
		const closeBtn = document.querySelector('.wx-inspector-close');
		const reprocessBtn = document.getElementById('wx-insp-btn-reprocess');
		const customWmBtn = document.getElementById('wx-insp-btn-custom-wm');
		const deleteBtn = document.getElementById('wx-insp-btn-delete');

		if (closeBtn) {
			closeBtn.addEventListener('click', closeInspector);
		}

		if (reprocessBtn) {
			reprocessBtn.addEventListener('click', () => {
				if (!state.activeItem) return;
				reprocessItem(state.activeItem.id, reprocessBtn);
			});
		}

		if (customWmBtn) {
			customWmBtn.addEventListener('click', () => {
				if (!state.activeItem) return;
				openCustomWatermarkModal(state.activeItem.id);
			});
		}

		if (deleteBtn) {
			deleteBtn.addEventListener('click', () => {
				if (!state.activeItem) return;
				if (!confirm(config.i18n.confirmDelete)) return;
				deleteSingleAttachment(state.activeItem.id);
			});
		}
	}

	function openInspector(item) {
		state.activeItem = item;
		const inspector = document.getElementById('wx-hub-inspector');
		if (!inspector) return;

		inspector.style.display = 'flex';

		// Set preview
		const preview = document.getElementById('wx-insp-preview');
		if (item.is_image) {
			preview.innerHTML = `<img src="${item.url}" alt="${escapeHtml(item.title)}">`;
		} else {
			preview.innerHTML = `<div class="wx-card-doc-preview">${item.type_badge}<span style="margin-top:8px;">${item.ext}</span></div>`;
		}

		// Metadata
		document.getElementById('wx-insp-name').textContent = item.filename || item.title;
		document.getElementById('wx-insp-format').textContent = item.ext + ' (' + item.mime + ')';
		document.getElementById('wx-insp-dim').textContent = item.dimensions || '—';
		document.getElementById('wx-insp-date').textContent = item.date || '—';

		// Download link
		const dlBtn = document.getElementById('wx-insp-btn-download');
		if (dlBtn) dlBtn.href = item.url;

		// Optimization box
		const optBox = document.getElementById('wx-insp-opt-box');
		const customWmBtn = document.getElementById('wx-insp-btn-custom-wm');
		const reprocessBtn = document.getElementById('wx-insp-btn-reprocess');

		if (item.is_image) {
			optBox.style.display = 'block';
			customWmBtn.style.display = 'inline-flex';
			reprocessBtn.style.display = 'inline-flex';

			document.getElementById('wx-insp-orig-size').textContent = item.orig_size_fmt || item.size_formatted;
			document.getElementById('wx-insp-opt-size').textContent = item.size_formatted;
			document.getElementById('wx-insp-savings-badge').textContent = '-' + Math.round(item.savings_percent) + '%';
			document.getElementById('wx-insp-opt-summary').textContent = item.is_optimized
				? (config.i18n.compressionSummary ? config.i18n.compressionSummary.replace('%d', Math.round(item.savings_percent)) : `WebP compression achieved ${Math.round(item.savings_percent)}% reduced payload.`)
				: (config.i18n.readyToOptimize || 'Ready to be optimized to WebP.');
		} else {
			optBox.style.display = 'none';
			customWmBtn.style.display = 'none';
			reprocessBtn.style.display = 'none';
		}
	}

	function closeInspector() {
		const inspector = document.getElementById('wx-hub-inspector');
		if (inspector) inspector.style.display = 'none';
		state.activeItem = null;
	}

	function deleteSingleAttachment(id) {
		const fd = new FormData();
		fd.append('action', 'worx_delete_attachment');
		fd.append('nonce', config.nonce);
		fd.append('attachment_id', id);

		fetch(config.ajaxUrl, { method: 'POST', body: fd })
			.then(r => r.json())
			.then(res => {
				if (res.success) {
					closeInspector();
					state.selectedIds.delete(id);
					updateBulkBar();
					fetchMedia();
				} else {
					alert(res.data && res.data.message ? res.data.message : config.i18n.error);
				}
			});
	}

	/* ==========================================================================
	   3. Floating Bulk Action Bar Operations
	   ========================================================================== */
	function initBulkActionBar() {
		const deselectBtn = document.getElementById('wx-bulk-action-deselect');
		const deleteBtn = document.getElementById('wx-bulk-action-delete');
		const optimizeBtn = document.getElementById('wx-bulk-action-optimize');

		if (deselectBtn) {
			deselectBtn.addEventListener('click', () => {
				state.selectedIds.clear();
				document.querySelectorAll('.wx-card.is-selected').forEach(c => c.classList.remove('is-selected'));
				document.querySelectorAll('.wx-card-check').forEach(cb => cb.checked = false);
				updateBulkBar();
			});
		}

		if (deleteBtn) {
			deleteBtn.addEventListener('click', () => {
				if (!state.selectedIds.size) return;
				if (!confirm(config.i18n.confirmBulk)) return;

				const fd = new FormData();
				fd.append('action', 'worx_bulk_delete');
				fd.append('nonce', config.nonce);
				Array.from(state.selectedIds).forEach(id => fd.append('attachment_ids[]', id));

				fetch(config.ajaxUrl, { method: 'POST', body: fd })
					.then(r => r.json())
					.then(res => {
						if (res.success) {
							state.selectedIds.clear();
							updateBulkBar();
							fetchMedia();
						}
					});
			});
		}

		if (optimizeBtn) {
			optimizeBtn.addEventListener('click', () => {
				if (!state.selectedIds.size) return;
				openBulkOptimizerModalWithIds(Array.from(state.selectedIds));
			});
		}
	}

	/* ==========================================================================
	   4. Upload Workspace Modal
	   ========================================================================== */
	function initUploadModal() {
		const modal = document.getElementById('wx-upload-modal');
		const dropzone = document.getElementById('wx-upload-dropzone');
		const fileInput = document.getElementById('wx-file-input');
		const closeBtn = modal ? modal.querySelector('.wx-modal-close') : null;
		const cancelBtn = modal ? modal.querySelector('.wx-modal-cancel') : null;

		if (!modal || !dropzone || !fileInput) return;

		[closeBtn, cancelBtn].forEach(b => {
			if (b) b.addEventListener('click', () => {
				modal.style.display = 'none';
				fetchMedia();
			});
		});

		// Drag & Drop
		['dragenter', 'dragover'].forEach(name => {
			dropzone.addEventListener(name, (e) => {
				e.preventDefault();
				dropzone.classList.add('is-dragover');
			});
		});

		['dragleave', 'drop'].forEach(name => {
			dropzone.addEventListener(name, (e) => {
				e.preventDefault();
				dropzone.classList.remove('is-dragover');
			});
		});

		dropzone.addEventListener('drop', (e) => {
			if (e.dataTransfer && e.dataTransfer.files) {
				handleUploadFiles(Array.from(e.dataTransfer.files));
			}
		});

		fileInput.addEventListener('change', () => {
			if (fileInput.files) {
				handleUploadFiles(Array.from(fileInput.files));
			}
		});
	}

	function openUploadModal() {
		const modal = document.getElementById('wx-upload-modal');
		if (modal) modal.style.display = 'flex';
	}

	function handleUploadFiles(files) {
		const queue = document.getElementById('wx-upload-queue');
		const queueItems = document.getElementById('wx-queue-items');
		if (!queue || !queueItems || !files.length) return;

		queue.style.display = 'flex';

		files.forEach(file => {
			const itemEl = document.createElement('div');
			itemEl.className = 'wx-queue-item';
			itemEl.innerHTML = `
				<span class="wx-queue-name">${escapeHtml(file.name)}</span>
				<div class="wx-queue-status">
					<span class="wx-queue-status-text">${config.i18n.working}</span>
				</div>
			`;
			queueItems.appendChild(itemEl);

			// Upload via AJAX
			const fd = new FormData();
			fd.append('action', 'worx_upload_file');
			fd.append('nonce', config.nonce);
			fd.append('file', file);

			fetch(config.ajaxUrl, { method: 'POST', body: fd })
				.then(r => r.json())
				.then(res => {
					const statusEl = itemEl.querySelector('.wx-queue-status');
					if (res.success) {
						statusEl.innerHTML = `
							<span class="wx-queue-savings">-${Math.round(res.data.savings)}%</span>
							<span class="wx-badge wx-badge-save">WebP</span>
						`;
					} else {
						statusEl.innerHTML = `<span style="color:#ef4444;">${config.i18n.error}</span>`;
					}
				})
				.catch(() => {
					const statusEl = itemEl.querySelector('.wx-queue-status');
					statusEl.innerHTML = `<span style="color:#ef4444;">${config.i18n.error}</span>`;
				});
		});
	}

	/* ==========================================================================
	   5. Custom Watermark Drag-and-Drop Modal Controller
	   ========================================================================== */
	function initCustomWatermarkModal() {
		const modal = document.getElementById('wx-custom-wm-modal');
		if (!modal) return;

		const closeBtn = modal.querySelector('.wx-modal-close');
		const cancelBtn = modal.querySelector('.wx-modal-cancel');
		const saveBtn = document.getElementById('wx-modal-save');
		const stage = document.getElementById('wx-modal-stage');
		const wm = document.getElementById('wx-modal-wm');
		const stageImg = document.getElementById('wx-modal-stage-img');
		const sizeRange = document.getElementById('wx-modal-size');
		const opacityRange = document.getElementById('wx-modal-opacity');
		const enableCheck = document.getElementById('wx-modal-wm-enable');
		const posBtns = modal.querySelectorAll('.wx-pos-btn');

		[closeBtn, cancelBtn].forEach(b => {
			if (b) b.addEventListener('click', () => { modal.style.display = 'none'; });
		});

		// Free Drag & Drop Mechanics
		let isDragging = false;
		let startX, startY;

		if (wm && stage) {
			wm.addEventListener('mousedown', startDrag);
			wm.addEventListener('touchstart', startDrag, { passive: false });

			window.addEventListener('mousemove', onDrag);
			window.addEventListener('touchmove', onDrag, { passive: false });

			window.addEventListener('mouseup', endDrag);
			window.addEventListener('touchend', endDrag);
		}

		function startDrag(e) {
			e.preventDefault();
			isDragging = true;
			const clientX = e.touches ? e.touches[0].clientX : e.clientX;
			const clientY = e.touches ? e.touches[0].clientY : e.clientY;
			startX = clientX;
			startY = clientY;
		}

		function onDrag(e) {
			if (!isDragging || !stage || !wm) return;
			e.preventDefault();
			const clientX = e.touches ? e.touches[0].clientX : e.clientX;
			const clientY = e.touches ? e.touches[0].clientY : e.clientY;

			const rect = stage.getBoundingClientRect();
			let x = ((clientX - rect.left) / rect.width) * 100;
			let y = ((clientY - rect.top) / rect.height) * 100;

			x = Math.max(5, Math.min(95, x));
			y = Math.max(5, Math.min(95, y));

			wm.style.left = x + '%';
			wm.style.top = y + '%';

			document.getElementById('wx-modal-x').value = Math.round(x);
			document.getElementById('wx-modal-y').value = Math.round(y);

			posBtns.forEach(b => b.classList.remove('is-active'));
		}

		function endDrag() {
			isDragging = false;
		}

		// Anchor Grid
		posBtns.forEach(b => {
			b.addEventListener('click', () => {
				posBtns.forEach(btn => btn.classList.remove('is-active'));
				b.classList.add('is-active');
				const x = b.dataset.x;
				const y = b.dataset.y;
				wm.style.left = x + '%';
				wm.style.top = y + '%';
				document.getElementById('wx-modal-x').value = x;
				document.getElementById('wx-modal-y').value = y;
				document.getElementById('wx-modal-pos').value = b.dataset.pos;
			});
		});

		// Controls
		if (sizeRange) {
			sizeRange.addEventListener('input', () => {
				document.getElementById('wx-modal-size-out').textContent = sizeRange.value + '%';
				wm.style.maxWidth = sizeRange.value + '%';
			});
		}

		if (opacityRange) {
			opacityRange.addEventListener('input', () => {
				document.getElementById('wx-modal-opacity-out').textContent = opacityRange.value + '%';
				wm.style.opacity = (opacityRange.value / 100);
			});
		}

		if (enableCheck) {
			enableCheck.addEventListener('change', () => {
				wm.style.display = enableCheck.checked ? 'block' : 'none';
			});
		}

		// Save & Apply
		if (saveBtn) {
			saveBtn.addEventListener('click', () => {
				const postId = document.getElementById('wx-modal-post-id').value;
				if (!postId) return;

				saveBtn.disabled = true;
				saveBtn.classList.add('is-busy');

				const fd = new FormData();
				fd.append('action', 'worx_save_custom_watermark');
				fd.append('nonce', config.nonce);
				fd.append('attachment_id', postId);
				fd.append('watermark_enabled', enableCheck.checked ? '1' : '0');
				fd.append('watermark_position', document.getElementById('wx-modal-pos').value);
				fd.append('watermark_x', document.getElementById('wx-modal-x').value);
				fd.append('watermark_y', document.getElementById('wx-modal-y').value);
				fd.append('watermark_size', sizeRange.value);
				fd.append('watermark_opacity', opacityRange.value);

				fetch(config.ajaxUrl, { method: 'POST', body: fd })
					.then(r => r.json())
					.then(res => {
						saveBtn.disabled = false;
						saveBtn.classList.remove('is-busy');
						if (res.success) {
							modal.style.display = 'none';
							fetchMedia();
						} else {
							alert(res.data && res.data.message ? res.data.message : config.i18n.error);
						}
					})
					.catch(() => {
						saveBtn.disabled = false;
						saveBtn.classList.remove('is-busy');
					});
			});
		}
	}

	function openCustomWatermarkModal(postId) {
		const modal = document.getElementById('wx-custom-wm-modal');
		const stageImg = document.getElementById('wx-modal-stage-img');
		const wm = document.getElementById('wx-modal-wm');
		if (!modal || !stageImg || !wm) return;

		document.getElementById('wx-modal-post-id').value = postId;

		const fd = new FormData();
		fd.append('action', 'worx_get_attachment_preview');
		fd.append('nonce', config.nonce);
		fd.append('attachment_id', postId);

		fetch(config.ajaxUrl, { method: 'POST', body: fd })
			.then(r => r.json())
			.then(res => {
				if (!res.success) return;
				const d = res.data;
				stageImg.src = d.url;
				wm.style.display = d.enabled ? 'block' : 'none';
				wm.style.left = d.x + '%';
				wm.style.top = d.y + '%';
				wm.style.maxWidth = d.size + '%';
				wm.style.opacity = (d.opacity / 100);

				document.getElementById('wx-modal-x').value = d.x;
				document.getElementById('wx-modal-y').value = d.y;
				document.getElementById('wx-modal-size').value = d.size;
				document.getElementById('wx-modal-size-out').textContent = d.size + '%';
				document.getElementById('wx-modal-opacity').value = d.opacity;
				document.getElementById('wx-modal-opacity-out').textContent = d.opacity + '%';
				document.getElementById('wx-modal-wm-enable').checked = d.enabled;

				modal.style.display = 'flex';
			});
	}

	/* ==========================================================================
	   6. Bulk Optimizer Runner Modal Controller
	   ========================================================================== */
	function initBulkOptimizerModal() {
		const modal = document.getElementById('wx-bulk-modal');
		const triggerBtn = document.getElementById('wx-hub-start-bulk-btn');
		const startBtn = document.getElementById('wx-bulk-start-btn');
		const closeBtn = document.getElementById('wx-bulk-close-btn');

		if (!modal) return;

		if (triggerBtn) {
			triggerBtn.addEventListener('click', () => {
				openBulkOptimizerModal();
			});
		}

		if (closeBtn) {
			closeBtn.addEventListener('click', () => {
				modal.style.display = 'none';
				fetchMedia();
			});
		}

		if (startBtn) {
			startBtn.addEventListener('click', () => {
				runBulkOptimization();
			});
		}
	}

	let bulkQueue = [];
	let bulkIndex = 0;
	let bulkRunning = false;

	function openBulkOptimizerModal() {
		const modal = document.getElementById('wx-bulk-modal');
		const log = document.getElementById('wx-bulk-log');
		const fill = document.getElementById('wx-bulk-fill');
		const countText = document.getElementById('wx-bulk-count-text');
		const pctText = document.getElementById('wx-bulk-pct');
		const startBtn = document.getElementById('wx-bulk-start-btn');

		if (!modal) return;

		fill.style.width = '0%';
		pctText.textContent = '0%';
		log.innerHTML = '';
		countText.textContent = config.i18n.working;
		startBtn.disabled = true;

		modal.style.display = 'flex';

		const fd = new FormData();
		fd.append('action', 'worx_get_bulk_candidates');
		fd.append('nonce', config.nonce);

		fetch(config.ajaxUrl, { method: 'POST', body: fd })
			.then(r => r.json())
			.then(res => {
				if (res.success && res.data.ids && res.data.ids.length > 0) {
					bulkQueue = res.data.ids;
					countText.textContent = config.i18n.foundCandidates ? config.i18n.foundCandidates.replace('%d', bulkQueue.length) : `Found ${bulkQueue.length} images ready for optimization.`;
					startBtn.disabled = false;
				} else {
					countText.textContent = config.i18n.allAlreadyOptimized || 'All images are already optimized with Worx!';
				}
			});
	}

	function openBulkOptimizerModalWithIds(ids) {
		const modal = document.getElementById('wx-bulk-modal');
		const log = document.getElementById('wx-bulk-log');
		const fill = document.getElementById('wx-bulk-fill');
		const countText = document.getElementById('wx-bulk-count-text');
		const pctText = document.getElementById('wx-bulk-pct');
		const startBtn = document.getElementById('wx-bulk-start-btn');

		if (!modal) return;

		bulkQueue = ids;
		fill.style.width = '0%';
		pctText.textContent = '0%';
		log.innerHTML = '';
		countText.textContent = config.i18n.selectedReady ? config.i18n.selectedReady.replace('%d', ids.length) : `${ids.length} selected images ready for optimization.`;
		startBtn.disabled = false;

		modal.style.display = 'flex';
	}

	function runBulkOptimization() {
		if (bulkRunning || !bulkQueue.length) return;
		bulkRunning = true;
		bulkIndex = 0;

		const startBtn = document.getElementById('wx-bulk-start-btn');
		startBtn.disabled = true;

		processNextBulkItem();
	}

	function processNextBulkItem() {
		const total = bulkQueue.length;
		if (bulkIndex >= total) {
			bulkRunning = false;
			document.getElementById('wx-bulk-count-text').textContent = config.i18n.bulkComplete;
			const startBtn = document.getElementById('wx-bulk-start-btn');
			startBtn.disabled = false;
			startBtn.textContent = config.i18n.done;
			return;
		}

		const id = bulkQueue[bulkIndex];
		const current = bulkIndex + 1;
		const pct = Math.round((current / total) * 100);

		document.getElementById('wx-bulk-fill').style.width = pct + '%';
		document.getElementById('wx-bulk-pct').textContent = pct + '%';
		document.getElementById('wx-bulk-count-text').textContent = config.i18n.optimizing ? config.i18n.optimizing.replace('%1$d', current).replace('%2$d', total) : `Optimizing ${current} of ${total}...`;

		const fd = new FormData();
		fd.append('action', 'worx_bulk_optimize_single');
		fd.append('nonce', config.nonce);
		fd.append('attachment_id', id);

		fetch(config.ajaxUrl, { method: 'POST', body: fd })
			.then(r => r.json())
			.then(res => {
				const log = document.getElementById('wx-bulk-log');
				const line = document.createElement('div');
				line.className = 'wx-bulk-log-line is-ok';
				if (res.success) {
					line.textContent = config.i18n.optimizedSavings
						? config.i18n.optimizedSavings.replace('%1$d', id).replace('%2$s', res.data.title || 'Image').replace('%3$d', Math.round(res.data.savings))
						: `[#${id}] ${res.data.title || 'Image'} optimized: -${Math.round(res.data.savings)}%`;
				} else {
					line.className = 'wx-bulk-log-line';
					line.style.color = '#ef4444';
					const errReason = res.data && res.data.message ? res.data.message : config.i18n.error;
					line.textContent = config.i18n.skipped
						? config.i18n.skipped.replace('%1$d', id).replace('%2$s', errReason)
						: `[#${id}] Skipped: ${errReason}`;
				}
				log.appendChild(line);
				log.scrollTop = log.scrollHeight;

				bulkIndex++;
				processNextBulkItem();
			})
			.catch(() => {
				bulkIndex++;
				processNextBulkItem();
			});
	}

	/* ==========================================================================
	   7. Reprocess Single Image (AJAX)
	   ========================================================================== */
	function reprocessItem(id, btn) {
		if (btn) btn.disabled = true;

		const fd = new FormData();
		fd.append('action', 'worx_reprocess_image');
		fd.append('nonce', config.nonce);
		fd.append('attachment_id', id);

		fetch(config.ajaxUrl, { method: 'POST', body: fd })
			.then(r => r.json())
			.then(res => {
				if (btn) btn.disabled = false;
				if (res.success) {
					fetchMedia();
					if (state.activeItem && state.activeItem.id === id) {
						state.activeItem.is_optimized = true;
						state.activeItem.savings_percent = res.data.meta.savings_percent;
						document.getElementById('wx-insp-savings-badge').textContent = '-' + Math.round(res.data.meta.savings_percent) + '%';
					}
				}
			})
			.catch(() => {
				if (btn) btn.disabled = false;
			});
	}

	/* ==========================================================================
	   8. Standard upload.php List Table Hooks
	   ========================================================================== */
	function initLegacyRowButtons() {
		document.addEventListener('click', (e) => {
			const customBtn = e.target.closest('[data-worx-custom-wm]');
			if (customBtn) {
				e.preventDefault();
				const id = customBtn.dataset.worxCustomWm;
				openCustomWatermarkModal(id);
				return;
			}

			const repBtn = e.target.closest('[data-worx-reprocess]');
			if (repBtn) {
				e.preventDefault();
				const id = repBtn.dataset.worxReprocess;
				const cell = repBtn.closest('.wx-hub-cell');
				const status = cell ? cell.querySelector('.wx-hub-status') : null;
				if (status) status.textContent = config.i18n.working;

				const fd = new FormData();
				fd.append('action', 'worx_reprocess_image');
				fd.append('nonce', config.nonce);
				fd.append('attachment_id', id);

				fetch(config.ajaxUrl, { method: 'POST', body: fd })
					.then(r => r.json())
					.then(res => {
						if (res.success && cell) {
							cell.outerHTML = res.data.html;
						}
					});
			}
		});
	}

	function escapeHtml(str) {
		if (!str) return '';
		return String(str)
			.replace(/&/g, '&amp;')
			.replace(/</g, '&lt;')
			.replace(/>/g, '&gt;')
			.replace(/"/g, '&quot;')
			.replace(/'/g, '&#039;');
	}
})();
