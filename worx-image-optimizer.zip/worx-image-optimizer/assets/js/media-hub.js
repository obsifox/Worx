/* Worx Media Hub, Bulk Optimizer & Custom Watermark Dialog - Vanilla JS */
(function () {
	'use strict';
	var cfg = window.worxHub || {};
	var ajaxUrl = cfg.ajaxUrl || '';
	var nonce = cfg.nonce || '';
	var logoSvg = cfg.logoSvg || '';
	var defaultWm = cfg.defaultWm || '';
	var i18n = cfg.i18n || {
		working: 'Processing...',
		done: 'Done',
		error: 'Error',
		saved: 'Watermark saved and image reprocessed!',
		bulkComplete: 'Bulk optimization complete!',
		optimizing: 'Optimizing image %1$d of %2$d...',
		customWmBtn: 'Adjust Watermark'
	};

	// 1. AJAX Reprocess handler in List View
	document.addEventListener('click', function (e) {
		var btn = e.target.closest ? e.target.closest('[data-worx-reprocess]') : null;
		if (!btn || btn.classList.contains('is-busy')) { return; }

		var id = btn.getAttribute('data-worx-reprocess');
		if (!id) { return; }

		var cell = btn.closest('.wx-hub-cell');
		var status = cell ? cell.querySelector('.wx-hub-status') : null;

		btn.classList.add('is-busy');
		if (status) {
			status.textContent = i18n.working;
			status.classList.remove('is-error');
		}

		var data = new URLSearchParams();
		data.append('action', 'worx_reprocess_image');
		data.append('nonce', nonce);
		data.append('attachment_id', id);

		fetch(ajaxUrl, {
			method: 'POST',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
			body: data.toString()
		})
		.then(function (res) { return res.json(); })
		.then(function (res) {
			btn.classList.remove('is-busy');
			if (res && res.success && res.data && res.data.html) {
				var parser = new DOMParser();
				var doc = parser.parseFromString(res.data.html, 'text/html');
				var fresh = doc.querySelector('.wx-hub-cell');
				if (fresh && cell) {
					cell.parentNode.replaceChild(fresh, cell);
				}
			} else {
				if (status) {
					status.textContent = (res && res.data && res.data.message) || i18n.error;
					status.classList.add('is-error');
				}
			}
		})
		.catch(function () {
			btn.classList.remove('is-busy');
			if (status) {
				status.textContent = i18n.error;
				status.classList.add('is-error');
			}
		});
	});

	// 2. Custom Watermark Modal (Per-Image Adjustment)
	var modalWm = document.getElementById('wx-custom-wm-modal');
	var stage = document.getElementById('wx-modal-stage');
	var stageImg = document.getElementById('wx-modal-stage-img');
	var wm = document.getElementById('wx-modal-wm');
	var inSize = document.getElementById('wx-modal-size');
	var outSize = document.getElementById('wx-modal-size-out');
	var inOp = document.getElementById('wx-modal-opacity');
	var outOp = document.getElementById('wx-modal-opacity-out');
	var inEnable = document.getElementById('wx-modal-wm-enable');
	var inX = document.getElementById('wx-modal-x');
	var inY = document.getElementById('wx-modal-y');
	var inPos = document.getElementById('wx-modal-pos');
	var inPostId = document.getElementById('wx-modal-post-id');
	var saveBtn = document.getElementById('wx-modal-save');
	var grid = document.getElementById('wx-modal-grid');

	var PRESETS = {
		'pos-tl': [0, 0],   'pos-tc': [50, 0],   'pos-tr': [100, 0],
		'pos-cl': [0, 50],  'pos-cc': [50, 50],  'pos-cr': [100, 50],
		'pos-bl': [0, 100], 'pos-bc': [50, 100], 'pos-br': [100, 100]
	};

	function updateModalWmLayout() {
		if (!stage || !wm || !stageImg) { return; }
		var x = parseFloat(inX ? inX.value : 90) || 0;
		var y = parseFloat(inY ? inY.value : 90) || 0;

		var sRect = stage.getBoundingClientRect();
		var wRect = wm.getBoundingClientRect();
		var maxL = Math.max(0, sRect.width - (wRect.width || (sRect.width * 0.25)));
		var maxT = Math.max(0, sRect.height - (wRect.height || (sRect.height * 0.15)));

		var leftPx = (x / 100) * maxL;
		var topPx = (y / 100) * maxT;

		wm.style.left = leftPx + 'px';
		wm.style.top = topPx + 'px';
	}

	function openCustomWmModal(attachmentId) {
		if (!modalWm) { return; }
		inPostId.value = attachmentId;
		modalWm.style.display = 'flex';
		wm.style.display = 'none';

		var data = new URLSearchParams();
		data.append('action', 'worx_get_attachment_preview');
		data.append('nonce', nonce);
		data.append('attachment_id', attachmentId);

		fetch(ajaxUrl, {
			method: 'POST',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
			body: data.toString()
		})
		.then(function (res) { return res.json(); })
		.then(function (res) {
			if (res && res.success && res.data) {
				var d = res.data;
				stageImg.src = d.url;
				stageImg.onload = function () {
					wm.style.display = d.enabled ? 'block' : 'none';
					inEnable.checked = d.enabled;
					inSize.value = d.size;
					if (outSize) { outSize.textContent = d.size + '%'; }
					wm.style.maxWidth = d.size + '%';

					inOp.value = d.opacity;
					if (outOp) { outOp.textContent = d.opacity + '%'; }
					wm.style.opacity = d.opacity / 100;

					inX.value = d.x;
					inY.value = d.y;
					inPos.value = d.position;

					if (grid) {
						var all = grid.querySelectorAll('button');
						for (var i = 0; i < all.length; i++) {
							all[i].classList.toggle('is-active', all[i].getAttribute('data-pos') === d.position);
						}
					}
					setTimeout(updateModalWmLayout, 50);
				};
			}
		});
	}

	// Trigger open modal on button click
	document.addEventListener('click', function (e) {
		var btn = e.target.closest ? e.target.closest('[data-worx-custom-wm]') : null;
		if (btn) {
			var id = btn.getAttribute('data-worx-custom-wm');
			if (id) { openCustomWmModal(id); }
		}

		if (e.target.closest && (e.target.closest('.wx-modal-close') || e.target.closest('.wx-modal-cancel'))) {
			var modal = e.target.closest('.wx-modal-backdrop');
			if (modal) { modal.style.display = 'none'; }
		}
	});

	// Controls inside Custom WM modal
	if (inSize) {
		inSize.addEventListener('input', function () {
			var val = parseInt(inSize.value, 10) || 25;
			wm.style.maxWidth = val + '%';
			if (outSize) { outSize.textContent = val + '%'; }
			setTimeout(updateModalWmLayout, 10);
		});
	}

	if (inOp) {
		inOp.addEventListener('input', function () {
			var val = parseInt(inOp.value, 10) || 85;
			wm.style.opacity = val / 100;
			if (outOp) { outOp.textContent = val + '%'; }
		});
	}

	if (inEnable) {
		inEnable.addEventListener('change', function () {
			wm.style.display = inEnable.checked ? 'block' : 'none';
		});
	}

	if (grid) {
		grid.addEventListener('click', function (e) {
			var b = e.target.closest ? e.target.closest('button') : null;
			if (!b) { return; }
			var p = b.getAttribute('data-pos');
			var x = parseFloat(b.getAttribute('data-x'));
			var y = parseFloat(b.getAttribute('data-y'));
			inX.value = x;
			inY.value = y;
			inPos.value = p;
			var all = grid.querySelectorAll('button');
			for (var i = 0; i < all.length; i++) {
				all[i].classList.toggle('is-active', all[i] === b);
			}
			updateModalWmLayout();
		});
	}

	// Drag & Drop on Modal Stage
	if (wm && stage) {
		var isDragging = false;
		var dragStartX = 0, dragStartY = 0;
		var initialLeftPx = 0, initialTopPx = 0;

		wm.addEventListener('mousedown', function (e) {
			if (e.button !== 0) { return; }
			isDragging = true;
			wm.classList.add('is-dragged');
			dragStartX = e.clientX;
			dragStartY = e.clientY;
			initialLeftPx = parseFloat(wm.style.left) || 0;
			initialTopPx = parseFloat(wm.style.top) || 0;
			e.preventDefault();
		});

		window.addEventListener('mousemove', function (e) {
			if (!isDragging) { return; }
			var deltaX = e.clientX - dragStartX;
			var deltaY = e.clientY - dragStartY;

			var sRect = stage.getBoundingClientRect();
			var wRect = wm.getBoundingClientRect();
			var maxL = Math.max(0, sRect.width - wRect.width);
			var maxT = Math.max(0, sRect.height - wRect.height);

			var newLeft = Math.max(0, Math.min(maxL, initialLeftPx + deltaX));
			var newTop = Math.max(0, Math.min(maxT, initialTopPx + deltaY));

			wm.style.left = newLeft + 'px';
			wm.style.top = newTop + 'px';

			var xPct = maxL > 0 ? (newLeft / maxL) * 100 : 0;
			var yPct = maxT > 0 ? (newTop / maxT) * 100 : 0;

			inX.value = Math.round(xPct);
			inY.value = Math.round(yPct);
			inPos.value = 'custom';

			if (grid) {
				var all = grid.querySelectorAll('button');
				for (var i = 0; i < all.length; i++) { all[i].classList.remove('is-active'); }
			}
		});

		window.addEventListener('mouseup', function () {
			if (isDragging) {
				isDragging = false;
				wm.classList.remove('is-dragged');
			}
		});
	}

	// Save Custom Watermark
	if (saveBtn) {
		saveBtn.addEventListener('click', function () {
			var id = inPostId ? inPostId.value : 0;
			if (!id) { return; }

			saveBtn.classList.add('is-busy');

			var data = new URLSearchParams();
			data.append('action', 'worx_save_custom_watermark');
			data.append('nonce', nonce);
			data.append('attachment_id', id);
			data.append('watermark_enabled', inEnable.checked ? 1 : 0);
			data.append('watermark_position', inPos.value);
			data.append('watermark_x', inX.value);
			data.append('watermark_y', inY.value);
			data.append('watermark_size', inSize.value);
			data.append('watermark_opacity', inOp.value);

			fetch(ajaxUrl, {
				method: 'POST',
				headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
				body: data.toString()
			})
			.then(function (res) { return res.json(); })
			.then(function (res) {
				saveBtn.classList.remove('is-busy');
				if (res && res.success) {
					modalWm.style.display = 'none';
					var cell = document.querySelector('.wx-hub-cell[data-post-id="' + id + '"]');
					if (cell && res.data && res.data.html) {
						var parser = new DOMParser();
						var doc = parser.parseFromString(res.data.html, 'text/html');
						var fresh = doc.querySelector('.wx-hub-cell');
						if (fresh) { cell.parentNode.replaceChild(fresh, cell); }
					}
				} else {
					alert((res && res.data && res.data.message) || i18n.error);
				}
			})
			.catch(function () {
				saveBtn.classList.remove('is-busy');
				alert(i18n.error);
			});
		});
	}

	// 3. Bulk Image Optimizer
	var openBulkBtn = document.getElementById('wx-open-bulk-modal');
	var modalBulk = document.getElementById('wx-bulk-modal');
	var bulkStartBtn = document.getElementById('wx-bulk-start-btn');
	var bulkFill = document.getElementById('wx-bulk-fill');
	var bulkPct = document.getElementById('wx-bulk-pct');
	var bulkCount = document.getElementById('wx-bulk-count-text');
	var bulkLog = document.getElementById('wx-bulk-log');

	var bulkIds = [];
	var bulkIndex = 0;
	var isBulkRunning = false;

	if (openBulkBtn && modalBulk) {
		openBulkBtn.addEventListener('click', function () {
			modalBulk.style.display = 'flex';
			bulkFill.style.width = '0%';
			bulkPct.textContent = '0%';
			bulkLog.innerHTML = '';
			bulkStartBtn.disabled = true;
			bulkCount.textContent = 'Scanning media library for unoptimized images...';

			var data = new URLSearchParams();
			data.append('action', 'worx_get_bulk_candidates');
			data.append('nonce', nonce);

			fetch(ajaxUrl, {
				method: 'POST',
				headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
				body: data.toString()
			})
			.then(function (res) { return res.json(); })
			.then(function (res) {
				if (res && res.success && res.data && res.data.ids) {
					bulkIds = res.data.ids;
					bulkIndex = 0;
					bulkCount.textContent = 'Found ' + bulkIds.length + ' unoptimized images.';
					bulkStartBtn.disabled = bulkIds.length === 0;
				}
			});
		});
	}

	function processNextBulk() {
		if (!isBulkRunning || bulkIndex >= bulkIds.length) {
			isBulkRunning = false;
			bulkStartBtn.disabled = false;
			bulkCount.textContent = i18n.bulkComplete;
			return;
		}

		var id = bulkIds[bulkIndex];
		bulkCount.textContent = 'Optimizing image ' + (bulkIndex + 1) + ' of ' + bulkIds.length + '...';

		var data = new URLSearchParams();
		data.append('action', 'worx_bulk_optimize_single');
		data.append('nonce', nonce);
		data.append('attachment_id', id);

		fetch(ajaxUrl, {
			method: 'POST',
			headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
			body: data.toString()
		})
		.then(function (res) { return res.json(); })
		.then(function (res) {
			bulkIndex++;
			var pct = Math.round((bulkIndex / bulkIds.length) * 100);
			bulkFill.style.width = pct + '%';
			bulkPct.textContent = pct + '%';

			var logItem = document.createElement('div');
			logItem.className = 'wx-bulk-log-item ' + (res.success ? 'success' : 'error');
			logItem.textContent = (res.success ? '✓ ' : '✗ ') + (res.data ? res.data.title : ('ID #' + id)) + (res.success ? (' (' + res.data.savings + '% saved)') : '');
			bulkLog.appendChild(logItem);
			bulkLog.scrollTop = bulkLog.scrollHeight;

			processNextBulk();
		})
		.catch(function () {
			bulkIndex++;
			processNextBulk();
		});
	}

	if (bulkStartBtn) {
		bulkStartBtn.addEventListener('click', function () {
			if (bulkIds.length === 0) { return; }
			isBulkRunning = true;
			bulkStartBtn.disabled = true;
			processNextBulk();
		});
	}

	// 4. Decorate Media Cards in Grid View with Worx Logo Badge
	function decorateCards() {
		var attachments = document.querySelectorAll('.attachments-browser .attachments .attachment:not([data-worx-decorated])');
		for (var i = 0; i < attachments.length; i++) {
			var att = attachments[i];
			att.setAttribute('data-worx-decorated', '1');

			var badge = document.createElement('span');
			badge.className = 'wx-card-badge';
			badge.innerHTML = (logoSvg ? logoSvg : '') + '<span class="wx-card-badge-label">Worx</span>';
			att.appendChild(badge);
		}
	}

	if (window.MutationObserver) {
		var observer = new MutationObserver(function () {
			decorateCards();
		});
		observer.observe(document.body, { childList: true, subtree: true });
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', decorateCards);
	} else {
		decorateCards();
	}
})();
