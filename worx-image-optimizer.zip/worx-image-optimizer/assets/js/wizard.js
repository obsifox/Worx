/* Worx Wizard - Vanilla JS live preview & drag-and-drop, 0 dependencies, 0 requests. */
(function () {
	'use strict';
	var stage = document.getElementById('wx-stage');
	var wm = document.getElementById('wx-wm');
	var op = document.getElementById('wx-opacity');
	var opOut = document.getElementById('wx-op-out');
	var size = document.getElementById('wx-size');
	var sizeOut = document.getElementById('wx-size-out');
	var pos = document.getElementById('wx-position');
	var grid = document.getElementById('wx-pos');
	var on = document.getElementById('wx-enabled');
	var sel = document.getElementById('wx-wm-select');
	var q = document.getElementById('wx-quality');
	var qOut = document.getElementById('wx-q-out');
	var inX = document.getElementById('wx-x');
	var inY = document.getElementById('wx-y');
	var modeBadge = document.getElementById('wx-mode-badge');

	if (!wm || !stage || !pos) { return; }

	var isDragging = false;
	var dragStartX = 0, dragStartY = 0;
	var initialLeftPx = 0, initialTopPx = 0;

	// 9-anchor preset percentages {code: [xPct, yPct]}
	var PRESETS = {
		'pos-tl': [0, 0],   'pos-tc': [50, 0],   'pos-tr': [100, 0],
		'pos-cl': [0, 50],  'pos-cc': [50, 50],  'pos-cr': [100, 50],
		'pos-bl': [0, 100], 'pos-bc': [50, 100], 'pos-br': [100, 100]
	};

	function updateLayout() {
		var x = parseFloat(wm.getAttribute('data-x')) || 0;
		var y = parseFloat(wm.getAttribute('data-y')) || 0;
		// Normalize 0-10 or 0-100 scale:
		if (x <= 10 && y <= 10 && x >= 0 && y >= 0 && (x === 0 || x === 5 || x === 10) && (y === 0 || y === 5 || y === 10)) {
			x = x * 10;
			y = y * 10;
		}

		var sRect = stage.getBoundingClientRect();
		var wRect = wm.getBoundingClientRect();
		var maxL = Math.max(0, sRect.width - (wRect.width || (sRect.width * 0.25)));
		var maxT = Math.max(0, sRect.height - (wRect.height || (sRect.height * 0.15)));

		var leftPx = (x / 100) * maxL;
		var topPx = (y / 100) * maxT;

		wm.style.left = leftPx + 'px';
		wm.style.top = topPx + 'px';
		wm.style.transform = 'none';

		if (inX) { inX.value = Math.round(x); }
		if (inY) { inY.value = Math.round(y); }
	}

	function activateButton(b) {
		var x = parseFloat(b.getAttribute('data-x'));
		var y = parseFloat(b.getAttribute('data-y'));
		var p = b.getAttribute('data-pos');

		wm.setAttribute('data-x', x);
		wm.setAttribute('data-y', y);
		pos.value = p;
		if (modeBadge) { modeBadge.textContent = p; }

		if (grid) {
			var all = grid.querySelectorAll('button');
			for (var i = 0; i < all.length; i++) {
				all[i].classList.toggle('is-active', all[i] === b);
			}
		}
		updateLayout();
	}

	// Watermark Size Slider
	if (size) {
		size.addEventListener('input', function () {
			var val = parseInt(size.value, 10) || 25;
			wm.style.maxWidth = val + '%';
			if (sizeOut) { sizeOut.textContent = val + '%'; }
			setTimeout(updateLayout, 10);
		});
	}

	// Watermark Opacity Slider
	if (op) {
		op.addEventListener('input', function () {
			var val = parseInt(op.value, 10) || 85;
			wm.style.opacity = val / 100;
			if (opOut) { opOut.textContent = val + '%'; }
		});
	}

	// 9-anchor matrix buttons
	if (grid) {
		grid.addEventListener('click', function (e) {
			var b = e.target.closest ? e.target.closest('button') : null;
			if (b) { activateButton(b); }
		});
	}

	// Switch toggle
	if (on) {
		on.addEventListener('change', function () {
			wm.style.display = on.checked ? '' : 'none';
		});
	}

	// Watermark image dropdown
	if (sel) {
		sel.addEventListener('change', function () {
			var o = sel.options[sel.selectedIndex];
			var s = o && o.getAttribute('data-src');
			if (s) {
				wm.src = s;
				setTimeout(updateLayout, 80);
			}
		});
	}

	// WebP quality
	if (q && qOut) {
		q.addEventListener('input', function () { qOut.textContent = q.value; });
	}

	// --- Drag & Drop Watermark on Canvas ---
	function onPointerDown(e) {
		if (e.button && e.button !== 0) { return; }
		isDragging = true;
		stage.classList.add('is-dragging');
		wm.classList.add('is-dragged');

		var clientX = e.touches ? e.touches[0].clientX : e.clientX;
		var clientY = e.touches ? e.touches[0].clientY : e.clientY;

		dragStartX = clientX;
		dragStartY = clientY;

		initialLeftPx = parseFloat(wm.style.left) || 0;
		initialTopPx = parseFloat(wm.style.top) || 0;

		e.preventDefault();
	}

	function onPointerMove(e) {
		if (!isDragging) { return; }

		var clientX = e.touches ? e.touches[0].clientX : e.clientX;
		var clientY = e.touches ? e.touches[0].clientY : e.clientY;

		var deltaX = clientX - dragStartX;
		var deltaY = clientY - dragStartY;

		var sRect = stage.getBoundingClientRect();
		var wRect = wm.getBoundingClientRect();

		var maxL = Math.max(0, sRect.width - wRect.width);
		var maxT = Math.max(0, sRect.height - wRect.height);

		var newLeft = Math.max(0, Math.min(maxL, initialLeftPx + deltaX));
		var newTop = Math.max(0, Math.min(maxT, initialTopPx + deltaY));

		wm.style.left = newLeft + 'px';
		wm.style.top = newTop + 'px';

		var xPct = maxL > 0 ? (newLeft / maxL) * 100 : 0;
		var yPct = maxT > 0 ? (newTop / maxT) * 100 : 0;

		wm.setAttribute('data-x', xPct);
		wm.setAttribute('data-y', yPct);

		if (inX) { inX.value = Math.round(xPct); }
		if (inY) { inY.value = Math.round(yPct); }

		// Check for snap to 9 presets
		var snapped = null;
		for (var k in PRESETS) {
			var px = PRESETS[k][0], py = PRESETS[k][1];
			if (Math.abs(px - xPct) < 7 && Math.abs(py - yPct) < 7) {
				snapped = k;
				break;
			}
		}

		if (grid) {
			var all = grid.querySelectorAll('button');
			for (var i = 0; i < all.length; i++) {
				var code = all[i].getAttribute('data-pos');
				all[i].classList.toggle('is-active', code === snapped);
			}
		}

		if (snapped) {
			pos.value = snapped;
			if (modeBadge) { modeBadge.textContent = snapped; }
		} else {
			pos.value = 'custom';
			if (modeBadge) { modeBadge.textContent = 'Custom drag position'; }
		}
	}

	function onPointerUp() {
		if (!isDragging) { return; }
		isDragging = false;
		stage.classList.remove('is-dragging');
		wm.classList.remove('is-dragged');
	}

	wm.addEventListener('mousedown', onPointerDown);
	wm.addEventListener('touchstart', onPointerDown, { passive: false });

	window.addEventListener('mousemove', onPointerMove);
	window.addEventListener('touchmove', onPointerMove, { passive: false });

	window.addEventListener('mouseup', onPointerUp);
	window.addEventListener('touchend', onPointerUp);

	// Initial render
	if (wm.complete) {
		updateLayout();
	} else {
		wm.addEventListener('load', updateLayout);
	}
	window.addEventListener('resize', updateLayout);
})();
