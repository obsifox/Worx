<?php
/**
 * Worx Internal Raster Engine.
 *
 * Fully self-contained inside the plugin. Handles raster manipulation,
 * aspect-ratio resizing, alpha layer blending, and WebP encoding without
 * relying on external CLI tools or third-party cloud services.
 *
 * @package Worx
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Worx_Internal_Engine {

	/**
	 * Active driver: 'imagick' | 'gd' | null.
	 *
	 * @var string|null
	 */
	private $driver = null;

	/**
	 * Constructor: auto-detects and binds internal PHP graphics driver.
	 */
	public function __construct() {
		$this->driver = $this->detect_driver();
	}

	/**
	 * Get the active driver.
	 *
	 * @return string|null
	 */
	public function driver() {
		return $this->driver;
	}

	/**
	 * Detect internal engine support.
	 *
	 * @return string|null
	 */
	private function detect_driver() {
		if ( class_exists( 'Imagick' ) ) {
			try {
				$probe = new Imagick();
				$probe->destroy();
				return 'imagick';
			} catch ( \Exception $e ) {
				// Fallback to internal GD
			}
		}

		if ( function_exists( 'imagewebp' ) && function_exists( 'imagecreatetruecolor' ) ) {
			return 'gd';
		}

		return null;
	}

	/**
	 * Human-readable engine label.
	 *
	 * @return string
	 */
	public function label() {
		if ( 'imagick' === $this->driver ) {
			$ver   = function_exists( 'imagick_version' ) ? imagick_version() : null;
			$label = ( is_array( $ver ) && isset( $ver['versionString'] ) ) ? ' ' . $ver['versionString'] : '';
			return 'Worx Internal Engine (Imagick' . $label . ')';
		}

		if ( 'gd' === $this->driver ) {
			$ver = function_exists( 'phpversion' ) ? phpversion( 'gd' ) : '';
			return 'Worx Internal Engine (GD ' . $ver . ')';
		}

		return __( 'None detected', 'worx' );
	}

	/**
	 * Check whether the internal engine can encode WebP.
	 *
	 * @return bool
	 */
	public function is_available() {
		return null !== $this->driver;
	}
}
