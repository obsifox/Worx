<?php
/**
 * Worx Internal Raster & WebP Engine.
 *
 * Fully self-contained inside the plugin. Handles raster manipulation,
 * aspect-ratio resizing, alpha layer blending, and WebP encoding without
 * relying on external CLI tools or third-party cloud services.
 *
 * Supported local internal drivers:
 *  1. PHP Imagick Extension: Native true-lossless WebP driver.
 *  2. PHP GD Extension: Native imagewebp driver.
 *  3. Bundled Standalone Binary: Static cwebp v1.5.0 in /bin/cwebp (0 shared libs).
 *  4. PicoWebP: 100% Pure-PHP VP8 WebP encoder (zero external requirements).
 *  5. WordPress Core Image Editor: WP_Image_Editor integration.
 *
 * @package Worx
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Worx_Internal_Engine {

	/**
	 * Active driver: 'imagick' | 'gd' | 'bundled_cwebp' | 'picowebp' | 'system_cwebp' | 'wp_editor'.
	 *
	 * @var string
	 */
	private $driver = 'picowebp';

	/**
	 * Path to binary if using binary driver.
	 *
	 * @var string|null
	 */
	private $binary_path = null;

	/**
	 * Constructor: auto-detects and binds the best internal graphics driver.
	 */
	public function __construct() {
		$this->register_autoloader();
		$this->driver = $this->detect_driver();
	}

	/**
	 * Register PSR-4 style autoloader for embedded pure-PHP engine.
	 *
	 * @return void
	 */
	private function register_autoloader() {
		spl_autoload_register(
			function ( $class ) {
				if ( 0 === strpos( $class, 'PicoWebP\\Vp8\\' ) ) {
					$rel = str_replace( 'PicoWebP\\Vp8\\', '', $class );
					if ( defined( 'WORX_PLUGIN_DIR' ) ) {
						$file = WORX_PLUGIN_DIR . 'includes/engine/picowebp/' . str_replace( '\\', '/', $rel ) . '.php';
						if ( file_exists( $file ) ) {
							require_once $file;
						}
					}
				}
			}
		);
	}

	/**
	 * Get the active driver identifier.
	 *
	 * @return string
	 */
	public function driver() {
		return $this->driver;
	}

	/**
	 * Binary path if applicable.
	 *
	 * @return string|null
	 */
	public function binary_path() {
		return $this->binary_path;
	}

	/**
	 * Returns false to signify that NO external APIs or cloud services are ever required.
	 *
	 * @return bool
	 */
	public function requires_external_services() {
		return false;
	}

	/**
	 * Check whether binary execution is permitted in this PHP runtime.
	 *
	 * @return bool
	 */
	public function can_exec_binary() {
		if ( ! function_exists( 'exec' ) && ! function_exists( 'proc_open' ) ) {
			return false;
		}

		$disabled = ini_get( 'disable_functions' );
		if ( ! empty( $disabled ) ) {
			$dis_arr = array_map( 'trim', explode( ',', strtolower( $disabled ) ) );
			if ( in_array( 'exec', $dis_arr, true ) && in_array( 'proc_open', $dis_arr, true ) ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Test if a given binary path is executable and responds to -version.
	 *
	 * @param string $path Path to executable.
	 * @return bool
	 */
	private function test_binary( $path ) {
		if ( ! file_exists( $path ) ) {
			return false;
		}

		// Ensure file has executable permissions
		if ( ! is_executable( $path ) ) {
			@chmod( $path, 0755 );
		}

		if ( ! is_executable( $path ) || ! $this->can_exec_binary() ) {
			return false;
		}

		$output   = array();
		$ret_code = 1;
		if ( function_exists( 'exec' ) ) {
			@exec( escapeshellcmd( $path ) . ' -version 2>&1', $output, $ret_code );
			return 0 === $ret_code;
		}

		return false;
	}

	/**
	 * Detect internal engine support in hierarchical priority:
	 * 1. PHP Imagick Extension
	 * 2. PHP GD Extension with WebP support
	 * 3. Bundled static binary (cwebp v1.5.0 inside /bin)
	 * 4. PicoWebP (Pure-PHP VP8 WebP engine, zero dependency)
	 * 5. WP_Image_Editor
	 *
	 * @return string
	 */
	private function detect_driver() {
		// Always locate binary path first so it is available for fallback or direct use
		if ( defined( 'WORX_PLUGIN_DIR' ) ) {
			$bundled = WORX_PLUGIN_DIR . 'bin/cwebp';
			if ( $this->test_binary( $bundled ) ) {
				$this->binary_path = $bundled;
			}
		}
		if ( ! $this->binary_path && $this->can_exec_binary() ) {
			$sys_paths = array( '/usr/bin/cwebp', '/usr/local/bin/cwebp', 'cwebp' );
			foreach ( $sys_paths as $p ) {
				if ( $this->test_binary( $p ) ) {
					$this->binary_path = $p;
					break;
				}
			}
		}

		// 1. Check PHP Imagick Extension
		if ( class_exists( 'Imagick' ) ) {
			try {
				$probe = new Imagick();
				$formats = $probe->queryFormats( 'WEBP' );
				$probe->destroy();
				if ( ! empty( $formats ) ) {
					return 'imagick';
				}
			} catch ( \Exception $e ) {
				// Continue to next driver
			}
		}

		// 2. Check PHP GD with WebP support
		if ( function_exists( 'imagewebp' ) && function_exists( 'imagecreatetruecolor' ) ) {
			return 'gd';
		}

		// 3. Bundled binary driver if GD/Imagick WebP not available
		if ( $this->binary_path ) {
			return 'bundled_cwebp';
		}

		// 4. Pure-PHP Embedded WebP Engine
		if ( class_exists( 'PicoWebP\\Vp8\\Vp8LossyEncoder' ) || file_exists( WORX_PLUGIN_DIR . 'includes/engine/picowebp/Vp8LossyEncoder.php' ) ) {
			return 'picowebp';
		}

		// 5. WordPress Core Image Editor
		if ( function_exists( 'wp_image_editor_supports' ) && wp_image_editor_supports( array( 'mime_type' => 'image/webp' ) ) ) {
			return 'wp_editor';
		}

		// Fallback to pure PHP or GD
		if ( function_exists( 'imagecreatetruecolor' ) ) {
			return 'gd';
		}

		return 'picowebp';
	}

	/**
	 * Human-readable engine label with autonomy badge.
	 *
	 * @return string
	 */
	public function label() {
		switch ( $this->driver ) {
			case 'imagick':
				$ver   = function_exists( 'imagick_version' ) ? imagick_version() : null;
				$label = ( is_array( $ver ) && isset( $ver['versionString'] ) ) ? ' ' . $ver['versionString'] : '';
				return 'Worx Internal Engine (PHP Imagick' . $label . ' • Native)';
			case 'gd':
				$ver = function_exists( 'phpversion' ) ? phpversion( 'gd' ) : '';
				return 'Worx Internal Engine (PHP GD ' . $ver . ' • Native)';
			case 'bundled_cwebp':
				return 'Worx Internal Engine (Bundled cwebp v1.5.0 • Self-Contained)';
			case 'picowebp':
				return 'Worx Internal Engine (Pure-PHP Embedded VP8 • Zero Dependencies)';
			case 'system_cwebp':
				return 'Worx Internal Engine (System cwebp • Standalone)';
			case 'wp_editor':
				return 'Worx Internal Engine (WordPress Core Editor)';
			default:
				return 'Worx Internal Engine (Autonomous Core)';
		}
	}

	/**
	 * Check whether the internal engine can encode WebP.
	 * Always true because PicoWebP is bundled directly inside the plugin.
	 *
	 * @return bool
	 */
	public function is_available() {
		return true;
	}

	/**
	 * Execute standalone WebP conversion via binary if available.
	 *
	 * @param string $src_file  Path to source image file.
	 * @param string $dest_file Path to destination WebP file.
	 * @param int    $quality   Compression quality (1-100).
	 * @return bool True on success, false on failure.
	 */
	public function convert_file_binary( $src_file, $dest_file, $quality = 85 ) {
		if ( ! $this->binary_path || ! file_exists( $src_file ) ) {
			return false;
		}

		$cmd = sprintf(
			'%s -q %d %s -o %s 2>&1',
			escapeshellcmd( $this->binary_path ),
			max( 1, min( 100, (int) $quality ) ),
			escapeshellarg( $src_file ),
			escapeshellarg( $dest_file )
		);

		$output   = array();
		$ret_code = 1;
		@exec( $cmd, $output, $ret_code );

		return ( 0 === $ret_code && file_exists( $dest_file ) && filesize( $dest_file ) > 0 );
	}

	/**
	 * Convert an image file to WebP using the pure-PHP embedded encoder.
	 *
	 * @param string $src_file  Source file path.
	 * @param string $dest_file Destination WebP path.
	 * @param int    $quality   Quality (1-100).
	 * @return bool
	 */
	public function convert_file_picowebp( $src_file, $dest_file, $quality = 85 ) {
		try {
			if ( ! class_exists( 'PicoWebP\\Vp8\\ImageInput' ) ) {
				$this->register_autoloader();
			}

			$pixels = \PicoWebP\Vp8\ImageInput::pixels( $src_file );
			$enc    = new \PicoWebP\Vp8\Vp8LossyEncoder( max( 1, min( 100, (int) $quality ) ) );
			$res    = $enc->encode( $pixels['rgb'], $pixels['w'], $pixels['h'], $pixels['alpha'] );

			if ( ! empty( $res['webp'] ) ) {
				$written = @file_put_contents( $dest_file, $res['webp'] );
				return ( $written === strlen( $res['webp'] ) && file_exists( $dest_file ) && filesize( $dest_file ) > 0 );
			}
		} catch ( \Throwable $e ) {
			error_log( 'Worx Pure-PHP Encoder Notice: ' . $e->getMessage() );
		}

		return false;
	}
}
