<?php
/**
 * Worx Internal Raster & WebP Engine.
 *
 * Fully self-contained inside the plugin. Handles raster manipulation,
 * aspect-ratio resizing, alpha layer blending, and WebP encoding without
 * relying on external CLI tools or third-party cloud services.
 *
 * Supported local internal drivers:
 *  1. Bundled Standalone Binary: Static cwebp v1.5.0 in /bin/cwebp (0 shared libs).
 *  2. PHP Imagick Extension: Native true-lossless WebP driver.
 *  3. PHP GD Extension: Native imagewebp driver.
 *  4. System CLI Binary: Pre-installed cwebp if accessible.
 *  5. WordPress Core Image Editor: WP_Image_Editor integration.
 *
 * @package Worx
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Worx_Internal_Engine {

	/**
	 * Active driver: 'bundled_cwebp' | 'imagick' | 'gd' | 'system_cwebp' | 'wp_editor' | null.
	 *
	 * @var string|null
	 */
	private $driver = null;

	/**
	 * Path to binary if using binary driver.
	 *
	 * @var string|null
	 */
	private $binary_path = null;

	/**
	 * Constructor: auto-detects and binds the best internal graphics driver.
	 */
	public function __construct() {
		$this->driver = $this->detect_driver();
	}

	/**
	 * Get the active driver identifier.
	 *
	 * @return string|null
	 */
	public function driver() {
		return $this->driver;
	}

	/**
	 * Binary path if applicable.
	 *
	 * @return string|null
	 */
	public function binary_path() {
		return $this->binary_path;
	}

	/**
	 * Returns false to signify that NO external APIs or cloud services are ever required.
	 *
	 * @return bool
	 */
	public function requires_external_services() {
		return false;
	}

	/**
	 * Check whether binary execution is permitted in this PHP runtime.
	 *
	 * @return bool
	 */
	public function can_exec_binary() {
		if ( ! function_exists( 'exec' ) && ! function_exists( 'proc_open' ) ) {
			return false;
		}

		$disabled = ini_get( 'disable_functions' );
		if ( ! empty( $disabled ) ) {
			$dis_arr = array_map( 'trim', explode( ',', strtolower( $disabled ) ) );
			if ( in_array( 'exec', $dis_arr, true ) && in_array( 'proc_open', $dis_arr, true ) ) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Test if a given binary path is executable and responds to -version.
	 *
	 * @param string $path Path to executable.
	 * @return bool
	 */
	private function test_binary( $path ) {
		if ( ! file_exists( $path ) || ! is_executable( $path ) ) {
			return false;
		}

		if ( ! $this->can_exec_binary() ) {
			return false;
		}

		$output   = array();
		$ret_code = 1;
		if ( function_exists( 'exec' ) ) {
			@exec( escapeshellcmd( $path ) . ' -version 2>&1', $output, $ret_code );
			return 0 === $ret_code;
		}

		return false;
	}

	/**
	 * Detect internal engine support in hierarchical priority:
	 * 1. Bundled static binary (cwebp v1.5.0 inside /bin)
	 * 2. PHP Imagick Extension
	 * 3. PHP GD Extension with WebP
	 * 4. System cwebp
	 * 5. WP_Image_Editor
	 *
	 * @return string|null
	 */
	private function detect_driver() {
		// Probe bundled binary path so it is always available as fallback
		if ( defined( 'WORX_PLUGIN_DIR' ) ) {
			$bundled = WORX_PLUGIN_DIR . 'bin/cwebp';
			if ( $this->test_binary( $bundled ) ) {
				$this->binary_path = $bundled;
			}
		}
		if ( ! $this->binary_path && $this->can_exec_binary() ) {
			$sys_paths = array( '/usr/bin/cwebp', '/usr/local/bin/cwebp', 'cwebp' );
			foreach ( $sys_paths as $p ) {
				if ( $this->test_binary( $p ) ) {
					$this->binary_path = $p;
					break;
				}
			}
		}

		// 1. Check PHP Imagick Extension
		if ( class_exists( 'Imagick' ) ) {
			try {
				$probe = new Imagick();
				$formats = $probe->queryFormats( 'WEBP' );
				$probe->destroy();
				if ( ! empty( $formats ) ) {
					return 'imagick';
				}
			} catch ( \Exception $e ) {
				// Continue to next driver
			}
		}

		// 2. Check PHP GD with WebP support
		if ( function_exists( 'imagewebp' ) && function_exists( 'imagecreatetruecolor' ) ) {
			return 'gd';
		}

		// 3. Bundled binary driver if GD/Imagick not available
		if ( $this->binary_path ) {
			return 'bundled_cwebp';
		}

		// 4. Check WordPress Core Image Editor
		if ( function_exists( 'wp_image_editor_supports' ) && wp_image_editor_supports( array( 'mime_type' => 'image/webp' ) ) ) {
			return 'wp_editor';
		}

		// Fallback for Imagick if queryFormats returned empty but extension exists
		if ( class_exists( 'Imagick' ) ) {
			return 'imagick';
		}

		// Fallback for GD if imagewebp exists
		if ( function_exists( 'imagewebp' ) ) {
			return 'gd';
		}

		return null;
	}

	/**
	 * Human-readable engine label with autonomy badge.
	 *
	 * @return string
	 */
	public function label() {
		switch ( $this->driver ) {
			case 'bundled_cwebp':
				return 'Worx Internal Engine (Bundled cwebp v1.5.0 • Self-Contained)';
			case 'imagick':
				$ver   = function_exists( 'imagick_version' ) ? imagick_version() : null;
				$label = ( is_array( $ver ) && isset( $ver['versionString'] ) ) ? ' ' . $ver['versionString'] : '';
				return 'Worx Internal Engine (PHP Imagick' . $label . ' • Native)';
			case 'gd':
				$ver = function_exists( 'phpversion' ) ? phpversion( 'gd' ) : '';
				return 'Worx Internal Engine (PHP GD ' . $ver . ' • Native)';
			case 'system_cwebp':
				return 'Worx Internal Engine (System cwebp • Standalone)';
			case 'wp_editor':
				return 'Worx Internal Engine (WordPress Core Editor)';
			default:
				return __( 'None detected', 'worx' );
		}
	}

	/**
	 * Check whether the internal engine can encode WebP.
	 *
	 * @return bool
	 */
	public function is_available() {
		return null !== $this->driver;
	}

	/**
	 * Execute standalone WebP conversion via binary if available.
	 *
	 * @param string $src_file  Path to source image file.
	 * @param string $dest_file Path to destination WebP file.
	 * @param int    $quality   Compression quality (1-100).
	 * @return bool True on success, false on failure.
	 */
	public function convert_file_binary( $src_file, $dest_file, $quality = 85 ) {
		if ( ! $this->binary_path || ! file_exists( $src_file ) ) {
			return false;
		}

		$cmd = sprintf(
			'%s -q %d %s -o %s 2>&1',
			escapeshellcmd( $this->binary_path ),
			max( 1, min( 100, (int) $quality ) ),
			escapeshellarg( $src_file ),
			escapeshellarg( $dest_file )
		);

		$output   = array();
		$ret_code = 1;
		@exec( $cmd, $output, $ret_code );

		return ( 0 === $ret_code && file_exists( $dest_file ) && filesize( $dest_file ) > 0 );
	}
}
