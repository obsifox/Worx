<?php
/**
 * Worx optimization pipeline with internal plugin engine.
 *
 * Single post-`wp_handle_upload` filter + retroactive bulk optimizer:
 *
 *   MIME sniff (real bytes) -> resize to max_width -> watermark (9 anchors or drag-and-drop)
 *   -> WebP encode via internal plugin engine -> atomic file swap
 *   -> metadata stored in `_worx_metadata` postmeta.
 *
 * Fallback Engine: if ANY step fails, the original file stays intact and the
 * upload proceeds completely unchanged.
 *
 * @package Worx
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Worx_Optimizer {

	const PENDING_OPTION   = 'worx_pending_meta';
	const META_KEY         = '_worx_metadata';
	const PENDING_WM_FLAG  = '_worx_needs_manual_wm';

	/**
	 * Plugin settings snapshot.
	 *
	 * @var array
	 */
	private $settings;

	/**
	 * Watermark engine.
	 *
	 * @var Worx_Watermark
	 */
	private $watermark;

	/**
	 * Internal engine instance.
	 *
	 * @var Worx_Internal_Engine
	 */
	private $internal_engine;

	/**
	 * Detected raster driver: 'imagick' | 'gd' | null.
	 *
	 * @var string|null
	 */
	private $engine;

	/**
	 * Constructor.
	 *
	 * @param array $settings Worx settings array.
	 */
	public function __construct( array $settings ) {
		$this->settings        = $settings;
		$this->watermark       = new Worx_Watermark( $settings );
		$this->internal_engine = new Worx_Internal_Engine();
		$this->engine          = $this->internal_engine->driver();
	}

	/**
	 * Conditional hook wiring.
	 *
	 * @return void
	 */
	public function hooks() {
		if ( empty( $this->settings['auto_webp'] ) && empty( $this->settings['watermark_enabled'] ) ) {
			return;
		}
		add_filter( 'wp_handle_upload', array( $this, 'process_upload' ), 20, 2 );
		add_action( 'add_attachment', array( $this, 'consume_pending_metadata' ), 10, 1 );
	}

	/**
	 * Detected engine id.
	 *
	 * @return string|null 'imagick' | 'gd' | null.
	 */
	public function engine() {
		return $this->engine;
	}

	/**
	 * Human readable engine label.
	 *
	 * @return string
	 */
	public function engine_label() {
		return $this->internal_engine->label();
	}

	/**
	 * Real-byte MIME sniff (security: declared name is never trusted).
	 *
	 * @param string $file Absolute file path.
	 * @return string MIME type or '' when unknown.
	 */
	private function sniff_mime( $file ) {
		if ( function_exists( 'finfo_open' ) ) {
			$fh = finfo_open( FILEINFO_MIME_TYPE );
			if ( $fh ) {
				$mime = finfo_file( $fh, $file );
				finfo_close( $fh );
				if ( $mime ) {
					return $mime;
				}
			}
		}
		$info = @getimagesize( $file );
		return $info ? $info['mime'] : '';
	}

	/**
	 * Savings percentage between two byte sizes.
	 *
	 * @param int $original  Original size in bytes.
	 * @param int $optimized Optimized size in bytes.
	 * @return float 0-100 with 2 decimals.
	 */
	private function savings_percent( $original, $optimized ) {
		if ( $original <= 0 ) {
			return 0;
		}
		return round( max( 0, ( $original - $optimized ) / $original * 100 ), 2 );
	}

	/**
	 * Build a public URL for an absolute uploads path.
	 *
	 * @param string $absolute Absolute file path.
	 * @return string
	 */
	private function url_for( $absolute ) {
		$uploads = wp_get_upload_dir();
		if ( ! empty( $uploads['basedir'] ) && 0 === strpos( $absolute, $uploads['basedir'] ) ) {
			return $uploads['baseurl'] . substr( $absolute, strlen( $uploads['basedir'] ) );
		}
		if ( defined( 'WP_CONTENT_DIR' ) && 0 === strpos( $absolute, WP_CONTENT_DIR ) ) {
			return content_url( substr( $absolute, strlen( WP_CONTENT_DIR ) ) );
		}
		return $absolute;
	}

	/**
	 * Path relative to the uploads directory root (how WP stores it).
	 *
	 * @param string $absolute Absolute file path.
	 * @return string
	 */
	private function uploads_relative_path( $absolute ) {
		$uploads = wp_get_upload_dir();
		if ( ! empty( $uploads['basedir'] ) && 0 === strpos( $absolute, $uploads['basedir'] ) ) {
			return ltrim( substr( $absolute, strlen( $uploads['basedir'] ) ), '/' );
		}
		if ( defined( 'WP_CONTENT_DIR' ) && 0 === strpos( $absolute, WP_CONTENT_DIR ) ) {
			return ltrim( substr( $absolute, strlen( WP_CONTENT_DIR ) ), '/' );
		}
		return wp_basename( $absolute );
	}

	/**
	 * wp_handle_upload filter callback.
	 *
	 * @param array $upload  WordPress upload result array.
	 * @param int   $post_id Parent post id (0 on async media uploads).
	 * @return array The (possibly rewritten) upload result.
	 */
	public function process_upload( $upload, $post_id = 0 ) {
		if ( ! is_array( $upload ) || is_wp_error( $upload ) ) {
			return $upload;
		}
		if ( empty( $upload['file'] ) || ! file_exists( $upload['file'] ) ) {
			return $upload;
		}
		if ( ! $this->internal_engine || ! $this->internal_engine->is_available() ) {
			$this->internal_engine = new Worx_Internal_Engine();
			$this->engine          = $this->internal_engine->driver();
		}

		$ext = strtolower( pathinfo( $upload['file'], PATHINFO_EXTENSION ) );
		if ( ! in_array( $ext, array( 'jpg', 'jpeg', 'png' ), true ) ) {
			return $upload; // Already WebP / GIF / non-image: pass through.
		}

		$mime = $this->sniff_mime( $upload['file'] );
		if ( ! in_array( $mime, array( 'image/jpeg', 'image/png' ), true ) ) {
			return $upload;
		}

		$dest = dirname( $upload['file'] ) . '/' . pathinfo( $upload['file'], PATHINFO_FILENAME ) . '.webp';

		// Check upload mode: auto vs manual watermark on upload
		$upload_mode = isset( $this->settings['watermark_upload_mode'] ) ? $this->settings['watermark_upload_mode'] : 'auto';
		$apply_settings = $this->settings;

		$defer_wm = ( 'manual' === $upload_mode && ! empty( $this->settings['watermark_enabled'] ) );
		if ( $defer_wm ) {
			// When manual mode is active, do not apply default watermark during initial upload.
			$apply_settings['watermark_enabled'] = false;
		}

		try {
			$result = $this->run_pipeline( $upload['file'], $apply_settings, $dest );
		} catch ( \Throwable $e ) {
			error_log( sprintf( 'Worx: pipeline failed for "%s": %s', $upload['file'], $e->getMessage() ) );
			return $upload;
		}

		$meta = array(
			'is_webp'           => true,
			'original_size'     => $result['original_size'],
			'optimized_size'    => $result['size'],
			'savings_percent'   => $this->savings_percent( $result['original_size'], $result['size'] ),
			'watermarked'       => ! empty( $apply_settings['watermark_enabled'] ),
			'needs_manual_wm'   => $defer_wm,
			'processed_at'      => time(),
			'engine'            => $this->engine,
		);

		if ( ! empty( $upload['post_ID'] ) ) {
			$this->finalize_attachment( (int) $upload['post_ID'], $result['file'], $meta );
			if ( $defer_wm ) {
				update_post_meta( (int) $upload['post_ID'], self::PENDING_WM_FLAG, 1 );
			}
		} else {
			if ( $defer_wm ) {
				$meta['needs_manual_wm'] = true;
			}
			$this->queue_metadata( $result['file'], $meta );
		}

		$upload['file'] = $result['file'];
		$upload['type'] = 'image/webp';
		$upload['url']  = $this->url_for( $result['file'] );

		return $upload;
	}

	/**
	 * Repoint an already-inserted attachment at the converted file and
	 * regenerate its sub-sizes from the WebP master.
	 *
	 * @param int    $post_id  Attachment post id.
	 * @param string $new_file Absolute path of the new master file.
	 * @param array  $meta     Worx metadata payload.
	 * @return void
	 */
	private function finalize_attachment( $post_id, $new_file, array $meta ) {
		if ( ! $post_id || ! function_exists( 'get_post_type' ) || 'attachment' !== get_post_type( $post_id ) ) {
			$this->queue_metadata( $new_file, $meta );
			return;
		}

		$old_file = function_exists( 'get_attached_file' ) ? get_attached_file( $post_id ) : '';
		$old_meta = function_exists( 'wp_get_attachment_metadata' ) ? wp_get_attachment_metadata( $post_id ) : false;
		if ( is_array( $old_meta ) && ! empty( $old_meta['sizes'] ) && $old_file ) {
			$dir = dirname( $old_file );
			foreach ( (array) $old_meta['sizes'] as $size ) {
				if ( ! empty( $size['file'] ) ) {
					$path = $dir . '/' . $size['file'];
					if ( file_exists( $path ) ) {
						@unlink( $path );
					}
				}
			}
		}

		update_attached_file( $post_id, $this->uploads_relative_path( $new_file ) );
		wp_update_post(
			array(
				'ID'             => $post_id,
				'post_mime_type' => 'image/webp',
			)
		);
		wp_update_attachment_metadata( $post_id, wp_generate_attachment_metadata( $post_id, $new_file ) );
		update_post_meta( $post_id, self::META_KEY, $meta );
	}

	/**
	 * Store metadata for the async flow, keyed by the absolute webp path.
	 *
	 * @param string $absolute_path New master file path.
	 * @param array  $meta          Worx metadata payload.
	 * @return void
	 */
	private function queue_metadata( $absolute_path, array $meta ) {
		$pending = get_option( self::PENDING_OPTION, array() );
		if ( ! is_array( $pending ) ) {
			$pending = array();
		}
		$now = time();
		foreach ( array_keys( $pending ) as $key ) {
			$queued_at = isset( $pending[ $key ]['queued_at'] ) ? (int) $pending[ $key ]['queued_at'] : 0;
			if ( ! $queued_at || ( $now - $queued_at ) > HOUR_IN_SECONDS ) {
				unset( $pending[ $key ] );
			}
		}
		$meta['queued_at'] = $now;
		$pending[ $absolute_path ] = $meta;
		update_option( self::PENDING_OPTION, $pending, false );
	}

	/**
	 * add_attachment hook: deliver queued metadata once the async-flow
	 * attachment row exists (matched by file basename).
	 *
	 * @param int $post_id New attachment id.
	 * @return void
	 */
	public function consume_pending_metadata( $post_id ) {
		$file = function_exists( 'get_attached_file' ) ? get_attached_file( $post_id ) : '';
		if ( ! $file ) {
			return;
		}
		$basename = wp_basename( $file );
		$pending  = get_option( self::PENDING_OPTION, array() );
		if ( ! is_array( $pending ) || empty( $pending ) ) {
			return;
		}

		$changed = false;
		foreach ( array_keys( $pending ) as $key ) {
			if ( wp_basename( (string) $key ) === $basename ) {
				$meta = $pending[ $key ];
				unset( $meta['queued_at'] );
				unset( $pending[ $key ] );
				$changed = true;
				update_post_meta( $post_id, self::META_KEY, $meta );
				if ( ! empty( $meta['needs_manual_wm'] ) ) {
					update_post_meta( $post_id, self::PENDING_WM_FLAG, 1 );
				}
			}
		}
		if ( $changed ) {
			update_option( self::PENDING_OPTION, $pending, false );
		}
	}

	/**
	 * Reprocess an attachment with optional custom per-image watermark settings.
	 *
	 * Rebuilds the WebP master from the untouched original when a
	 * "-original" sibling exists, otherwise re-runs the current master.
	 *
	 * @param int        $post_id         Attachment post id.
	 * @param array|null $custom_settings Optional custom watermark overrides for this single image.
	 * @return array Final metadata.
	 * @throws \RuntimeException When the operation cannot be completed.
	 */
	public function reprocess_attachment( $post_id, $custom_settings = null ) {
		$file = get_attached_file( $post_id );
		if ( ! $file || ! file_exists( $file ) ) {
			throw new \RuntimeException( __( 'Attached file not found on disk.', 'worx' ) );
		}
		if ( ! $this->internal_engine || ! $this->internal_engine->is_available() ) {
			$this->internal_engine = new Worx_Internal_Engine();
			$this->engine          = $this->internal_engine->driver();
		}

		$info = pathinfo( $file );
		$dir  = $info['dirname'];
		$name = $info['filename'];
		$ext  = strtolower( $info['extension'] );

		$existing      = get_post_meta( $post_id, self::META_KEY, true );
		$true_original = ( is_array( $existing ) && ! empty( $existing['original_size'] ) ) ? (int) $existing['original_size'] : (int) filesize( $file );

		if ( 'webp' === $ext ) {
			$sib = null;
			foreach ( array( 'jpg', 'jpeg', 'png' ) as $oext ) {
				$candidate = $dir . '/' . $name . '-original.' . $oext;
				if ( file_exists( $candidate ) ) {
					$sib = $candidate;
					break;
				}
			}
			if ( $sib ) {
				$src  = $sib;
				$dest = $file;
			} else {
				$src  = $file;
				$dest = $dir . '/' . $name . '.wx.webp';
			}
		} else {
			// Legacy image never optimized before
			$src  = $file;
			$dest = $dir . '/' . $name . '.webp';
		}

		$mime = $this->sniff_mime( $src );
		if ( ! in_array( $mime, array( 'image/jpeg', 'image/png', 'image/webp' ), true ) ) {
			throw new \RuntimeException( __( 'Unsupported image format.', 'worx' ) );
		}

		// Apply custom per-image settings if provided
		$effective_settings = $this->settings;
		if ( is_array( $custom_settings ) && ! empty( $custom_settings ) ) {
			$effective_settings = wp_parse_args( $custom_settings, $this->settings );
		}

		$result = $this->run_pipeline( $src, $effective_settings, $dest );

		$final = $dir . '/' . $name . '.webp';
		if ( $result['file'] !== $final ) {
			if ( file_exists( $final ) ) {
				@unlink( $final );
			}
			if ( ! rename( $result['file'], $final ) ) {
				throw new \RuntimeException( __( 'Could not move the WebP file into place.', 'worx' ) );
			}
			$result['file'] = $final;
			$result['size'] = (int) filesize( $final );
		}

		if ( $final !== $file && file_exists( $file ) ) {
			@unlink( $file );
			update_attached_file( $post_id, $this->uploads_relative_path( $final ) );
			wp_update_post(
				array(
					'ID'             => $post_id,
					'post_mime_type' => 'image/webp',
				)
			);
		}

		wp_update_attachment_metadata( $post_id, wp_generate_attachment_metadata( $post_id, $final ) );

		$meta = array(
			'is_webp'         => true,
			'original_size'   => $true_original,
			'optimized_size'  => $result['size'],
			'savings_percent' => $this->savings_percent( $true_original, $result['size'] ),
			'watermarked'     => ! empty( $effective_settings['watermark_enabled'] ),
			'processed_at'    => time(),
			'engine'          => $this->engine,
		);

		if ( is_array( $custom_settings ) && ! empty( $custom_settings ) ) {
			$meta['custom_watermark'] = $custom_settings;
		}

		update_post_meta( $post_id, self::META_KEY, $meta );
		if ( function_exists( 'delete_post_meta' ) ) {
			delete_post_meta( $post_id, self::PENDING_WM_FLAG );
		}

		return $meta;
	}

	/**
	 * Run the full conversion for one file.
	 *
	 * @param string $src      Source file (absolute).
	 * @param array  $settings Settings snapshot.
	 * @param string $dest     Final destination (absolute).
	 * @return array {file, size, original_size}.
	 * @throws \RuntimeException On any hard failure.
	 */
	private function run_pipeline( $src, array $settings, $dest ) {
		$src  = (string) realpath( $src );
		$dest = (string) $dest;
		if ( ! $src || ! is_file( $src ) ) {
			throw new \RuntimeException( __( 'Source file is missing.', 'worx' ) );
		}
		if ( $dest === $src ) {
			throw new \RuntimeException( __( 'Destination must differ from source.', 'worx' ) );
		}

		$original_size = (int) filesize( $src );
		$tmp           = $dest . '.wx-tmp.webp';
		if ( file_exists( $tmp ) ) {
			@unlink( $tmp );
		}

		$max_width = isset( $settings['max_width'] ) ? (int) $settings['max_width'] : 1920;
		$quality   = isset( $settings['lossless_quality'] ) ? max( 60, min( 100, (int) $settings['lossless_quality'] ) ) : 100;
		$do_wm     = ! empty( $settings['watermark_enabled'] );

		if ( 'imagick' === $this->engine ) {
			$this->encode_imagick( $src, $tmp, $max_width, $quality, $do_wm, $settings );
		} elseif ( function_exists( 'imagecreatetruecolor' ) ) {
			$this->encode_gd( $src, $tmp, $max_width, $quality, $do_wm, $settings );
		} elseif ( $this->internal_engine && $this->internal_engine->binary_path() ) {
			$ok = $this->internal_engine->convert_file_binary( $src, $tmp, $quality );
			if ( ! $ok ) {
				$ok = $this->internal_engine->convert_file_picowebp( $src, $tmp, $quality );
			}
			if ( ! $ok ) {
				throw new \RuntimeException( __( 'WebP encoding failed with internal binary engine.', 'worx' ) );
			}
		} else {
			$ok = $this->internal_engine->convert_file_picowebp( $src, $tmp, $quality );
			if ( ! $ok ) {
				throw new \RuntimeException( __( 'WebP encoding failed with internal pure-PHP engine.', 'worx' ) );
			}
		}

		if ( ! file_exists( $tmp ) ) {
			throw new \RuntimeException( __( 'WebP encoding failed - no output file produced.', 'worx' ) );
		}

		if ( file_exists( $dest ) ) {
			@unlink( $dest );
		}
		if ( ! rename( $tmp, $dest ) ) {
			throw new \RuntimeException( __( 'Could not move the WebP file into place.', 'worx' ) );
		}

		$ext = strtolower( pathinfo( $src, PATHINFO_EXTENSION ) );
		if ( in_array( $ext, array( 'jpg', 'jpeg', 'png' ), true ) ) {
			if ( ! empty( $settings['delete_original'] ) ) {
				@unlink( $src );
			} else {
				$sib = dirname( $src ) . '/' . pathinfo( $src, PATHINFO_FILENAME ) . '-original.' . $ext;
				if ( file_exists( $sib ) ) {
					@unlink( $sib );
				}
				rename( $src, $sib );
			}
		}

		return array(
			'file'          => $dest,
			'size'          => (int) filesize( $dest ),
			'original_size' => $original_size,
		);
	}

	/**
	 * GD encode path.
	 *
	 * @param string $src       Source file.
	 * @param string $dest      Output file.
	 * @param int    $max_width Max width.
	 * @param int    $quality   Quality.
	 * @param bool   $do_wm     Watermark toggle.
	 * @param array  $settings  Settings snapshot.
	 * @return void
	 */
	private function encode_gd( $src, $dest, $max_width, $quality, $do_wm, array $settings ) {
		$mime = $this->sniff_mime( $src );
		$img  = null;
		switch ( $mime ) {
			case 'image/jpeg':
				$img = @imagecreatefromjpeg( $src );
				break;
			case 'image/png':
				$img = @imagecreatefrompng( $src );
				break;
			case 'image/webp':
				$img = @imagecreatefromwebp( $src );
				break;
		}
		if ( ! $img ) {
			throw new \RuntimeException( sprintf( 'GD could not read "%s".', $src ) );
		}

		if ( ! imageistruecolor( $img ) ) {
			$tmp_img = imagecreatetruecolor( imagesx( $img ), imagesy( $img ) );
			imagecopy( $tmp_img, $img, 0, 0, 0, 0, imagesx( $img ), imagesy( $img ) );
			imagedestroy( $img );
			$img = $tmp_img;
		}
		imagesavealpha( $img, true );

		$w = imagesx( $img );
		$h = imagesy( $img );
		if ( $max_width > 0 && $w > $max_width ) {
			$new_h = max( 1, (int) round( $h * $max_width / $w ) );
			$res   = imagecreatetruecolor( $max_width, $new_h );
			imagealphablending( $res, false );
			imagesavealpha( $res, true );
			$bg = imagecolorallocatealpha( $res, 0, 0, 0, 127 );
			imagefill( $res, 0, 0, $bg );
			imagecopyresampled( $res, $img, 0, 0, 0, 0, $max_width, $new_h, $w, $h );
			imagedestroy( $img );
			$img = $res;
			$w   = $max_width;
			$h   = $new_h;
		}

		if ( $do_wm ) {
			// Build custom watermark instance if custom parameters provided
			$wm_engine = ( isset( $settings['watermark_position'] ) || isset( $settings['watermark_size'] ) )
				? new Worx_Watermark( $settings )
				: $this->watermark;
			$img = $wm_engine->apply_gd( $img, $settings );
		}

		$ok = function_exists( 'imagewebp' ) ? @imagewebp( $img, $dest, $quality ) : false;

		// Fallback to bundled internal cwebp binary if imagewebp is missing or failed
		if ( ! $ok && $this->internal_engine && $this->internal_engine->binary_path() ) {
			$tmp_png = $dest . '.tmp.png';
			imagepng( $img, $tmp_png );
			$ok = $this->internal_engine->convert_file_binary( $tmp_png, $dest, $quality );
			@unlink( $tmp_png );
		}

		// Fallback to pure-PHP internal WebP encoder (100% autonomous)
		if ( ! $ok && $this->internal_engine ) {
			$tmp_png = $dest . '.tmp.png';
			imagepng( $img, $tmp_png );
			$ok = $this->internal_engine->convert_file_picowebp( $tmp_png, $dest, $quality );
			@unlink( $tmp_png );
		}

		imagedestroy( $img );
		if ( ! $ok ) {
			throw new \RuntimeException( 'WebP conversion failed - no working internal encoder available.' );
		}
	}

	/**
	 * Imagick encode path.
	 *
	 * @param string $src       Source file.
	 * @param string $dest      Output file.
	 * @param int    $max_width Max width.
	 * @param int    $quality   Quality.
	 * @param bool   $do_wm     Watermark toggle.
	 * @param array  $settings  Settings snapshot.
	 * @return void
	 */
	private function encode_imagick( $src, $dest, $max_width, $quality, $do_wm, array $settings ) {
		try {
			$im = new Imagick( $src );
		} catch ( \Exception $e ) {
			throw new \RuntimeException( sprintf( 'Imagick could not read "%s".', $src ) );
		}

		if ( method_exists( $im, 'autoOrient' ) ) {
			$im->autoOrient();
		}
		$im->setImageFormat( 'webp' );

		$w = $im->getImageWidth();
		if ( $max_width > 0 && $w > $max_width ) {
			$im->resizeImage( $max_width, 0, Imagick::FilterLanczos, 1, true );
		}

		if ( $do_wm ) {
			$wm_engine = ( isset( $settings['watermark_position'] ) || isset( $settings['watermark_size'] ) )
				? new Worx_Watermark( $settings )
				: $this->watermark;
			$im = $wm_engine->apply_imagick( $im, $settings );
		}

		if ( 100 === $quality ) {
			$im->setOption( 'webp:lossless', 'true' );
			$im->setImageCompressionQuality( 100 );
		} else {
			$im->setImageCompressionQuality( $quality );
		}

		$ok = $im->writeImage( $dest );
		$im->clear();
		$im->destroy();
		if ( ! $ok ) {
			throw new \RuntimeException( 'Imagick writeImage() failed.' );
		}
	}

	/**
	 * Query legacy unoptimized attachments in database.
	 *
	 * @param int $limit Number of attachment IDs to retrieve (0 for all).
	 * @return array Array of attachment IDs.
	 */
	public function get_unoptimized_attachment_ids( $limit = 0 ) {
		global $wpdb;
		$limit_sql = $limit > 0 ? $wpdb->prepare( 'LIMIT %d', $limit ) : '';

		$query = "SELECT p.ID FROM {$wpdb->posts} p
			LEFT JOIN {$wpdb->postmeta} pm ON (p.ID = pm.post_id AND pm.meta_key = %s)
			WHERE p.post_type = 'attachment'
			  AND p.post_status = 'inherit'
			  AND p.post_mime_type IN ('image/jpeg', 'image/png')
			  AND pm.meta_id IS NULL
			ORDER BY p.ID DESC {$limit_sql}";

		$ids = $wpdb->get_col( $wpdb->prepare( $query, self::META_KEY ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
		return array_map( 'intval', (array) $ids );
	}
}
