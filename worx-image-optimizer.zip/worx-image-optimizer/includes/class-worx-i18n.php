<?php
/**
 * Worx i18n loader with intelligent automatic language detection.
 *
 * Automatically detects WordPress site locale and individual user locale.
 * Switches seamlessly between English and Persian (fa-IR), adjusting
 * text domains, translations, and RTL layout directions dynamically.
 *
 * @package Worx
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Worx_I18n {

	/**
	 * Detect active locale for the current request.
	 *
	 * Checks user profile locale first (WP 4.7+), falling back to site locale.
	 *
	 * @return string Normalized locale code (e.g. 'fa_IR' or 'en_US').
	 */
	public static function get_locale() {
		$locale = 'en_US';
		if ( function_exists( 'get_user_locale' ) ) {
			$locale = get_user_locale();
		} elseif ( function_exists( 'get_locale' ) ) {
			$locale = get_locale();
		}

		if ( empty( $locale ) ) {
			$locale = 'en_US';
		}

		return $locale;
	}

	/**
	 * Check whether the active locale is Persian (fa-IR or fa_*).
	 *
	 * @return bool
	 */
	public static function is_persian() {
		$loc = self::get_locale();
		return ( 0 === strpos( $loc, 'fa' ) || 'fa_IR' === $loc );
	}

	/**
	 * Load the text domain with automatic language mapping.
	 *
	 * @return void
	 */
	public function load() {
		$plugin_rel_path = dirname( plugin_basename( WORX_PLUGIN_FILE ) ) . '/languages';

		// Standard WordPress textdomain loading.
		load_plugin_textdomain( 'worx', false, $plugin_rel_path );

		// If user or site is Persian, explicitly ensure bundled Persian MO is loaded.
		if ( self::is_persian() ) {
			$mo_file = WORX_PLUGIN_DIR . 'languages/worx-fa_IR.mo';
			if ( file_exists( $mo_file ) ) {
				load_textdomain( 'worx', $mo_file );
			}
		}

		add_filter( 'admin_body_class', array( $this, 'filter_admin_body_class' ) );
	}

	/**
	 * Append language and Worx theme classes to admin body for styling precision.
	 *
	 * @param string $classes Space-separated classes.
	 * @return string
	 */
	public function filter_admin_body_class( $classes ) {
		$lang_class = self::is_persian() ? 'worx-lang-fa' : 'worx-lang-en';
		return $classes . ' ' . $lang_class . ' worx-theme-active ';
	}
}
