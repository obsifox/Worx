<?php
/**
 * Worx Media Hub: Complete UI/UX Redesign.
 *
 * Replaces generic WordPress media library visuals with a cohesive, premium,
 * modern SaaS-style media management application:
 *  - Dedicated Worx Media Hub workspace with compact branded header.
 *  - Responsive media grid and list view with rich cards.
 *  - Worx file-type indicator system (WX IMG, WX WEBP, WX VIDEO, WX DOC).
 *  - Real-time search by filename, extension, and WebP status.
 *  - Compact category filters and multi-criteria sorting.
 *  - Slide-out media inspector details drawer with optimization comparison.
 *  - Floating bulk action bar (Optimize, Delete, Deselect).
 *  - Integrated drag-and-drop upload workspace and progress queue.
 *  - Modal dialogs for per-image watermark drag-and-drop & bulk optimizer.
 *  - Pure Vanilla JS, accessible, zero external dependencies, high performance.
 *
 * @package Worx
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Worx_Media_Hub {

	const PAGE         = 'worx-media-hub';
	const NONCE_ACTION = 'worx_media_action';

	/**
	 * Plugin settings snapshot.
	 *
	 * @var array
	 */
	private $settings;

	/**
	 * Constructor.
	 *
	 * @param array $settings Worx settings array.
	 */
	public function __construct( array $settings ) {
		$this->settings = $settings;
	}

	/**
	 * Hook wiring.
	 *
	 * @return void
	 */
	public function hooks() {
		// Admin menus
		add_action( 'admin_menu', array( $this, 'register_menu' ) );

		// Standard Media Library column & row hooks (preserved for list mode)
		add_filter( 'manage_media_library_columns', array( $this, 'add_column' ) );
		add_action( 'manage_media_library_custom_column', array( $this, 'render_column' ), 10, 3 );
		add_filter( 'post_row_classes', array( $this, 'row_classes' ), 10, 2 );
		add_action( 'admin_notices', array( $this, 'render_stats_bar' ) );
		add_action( 'admin_footer', array( $this, 'render_modals' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		add_action( 'wp_enqueue_media', array( $this, 'enqueue_media_modal_assets' ) );
		add_action( 'post-upload-ui', array( $this, 'render_uploader_badge' ) );

		// AJAX Endpoints
		add_action( 'wp_ajax_worx_get_hub_media', array( $this, 'ajax_get_hub_media' ) );
		add_action( 'wp_ajax_worx_upload_file', array( $this, 'ajax_upload_file' ) );
		add_action( 'wp_ajax_worx_delete_attachment', array( $this, 'ajax_delete_attachment' ) );
		add_action( 'wp_ajax_worx_bulk_delete', array( $this, 'ajax_bulk_delete' ) );
		add_action( 'wp_ajax_worx_reprocess_image', array( $this, 'ajax_reprocess' ) );
		add_action( 'wp_ajax_worx_get_bulk_candidates', array( $this, 'ajax_get_bulk_candidates' ) );
		add_action( 'wp_ajax_worx_bulk_optimize_single', array( $this, 'ajax_bulk_optimize_single' ) );
		add_action( 'wp_ajax_worx_get_attachment_preview', array( $this, 'ajax_get_attachment_preview' ) );
		add_action( 'wp_ajax_worx_save_custom_watermark', array( $this, 'ajax_save_custom_watermark' ) );
	}

	/**
	 * Register the dedicated Worx Media Hub screen under Media.
	 *
	 * @return void
	 */
	public function register_menu() {
		if ( ! current_user_can( 'upload_files' ) ) {
			return;
		}

		add_submenu_page(
			'upload.php',
			__( 'Worx Media Hub', 'worx' ),
			__( 'Worx Media Hub', 'worx' ),
			'upload_files',
			self::PAGE,
			array( $this, 'render_hub_page' )
		);
	}

	/**
	 * Format byte sizes into human readable units.
	 *
	 * @param int $bytes Bytes count.
	 * @return string Formatted size.
	 */
	public static function format_bytes( $bytes ) {
		if ( $bytes <= 0 ) {
			return '0 B';
		}
		$units = array( 'B', 'KB', 'MB', 'GB' );
		$exp   = (int) floor( log( $bytes, 1024 ) );
		$exp   = min( $exp, count( $units ) - 1 );
		return round( $bytes / pow( 1024, $exp ), 1 ) . ' ' . $units[ $exp ];
	}

	/**
	 * Render the complete SaaS Worx Media Hub workspace.
	 *
	 * @return void
	 */
	public function render_hub_page() {
		if ( ! current_user_can( 'upload_files' ) ) {
			wp_die( esc_html__( 'Permission denied.', 'worx' ) );
		}

		$stats = get_transient( 'worx_hub_stats' );
		if ( ! is_array( $stats ) ) {
			global $wpdb;
			$total = ( $wpdb && isset( $wpdb->posts ) ) ? (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'attachment' AND post_status = 'inherit'" ) : 0; // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$opt   = ( $wpdb && isset( $wpdb->posts ) ) ? (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(DISTINCT p.ID) FROM {$wpdb->posts} p INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID AND pm.meta_key = %s WHERE p.post_type = 'attachment' AND p.post_status = 'inherit'", Worx_Optimizer::META_KEY ) ) : 0; // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$stats = array(
				'total'     => $total,
				'optimized' => $opt,
			);
			set_transient( 'worx_hub_stats', $stats, 5 * MINUTE_IN_SECONDS );
		}

		$total_count = (int) $stats['total'];
		$opt_count   = (int) $stats['optimized'];
		$unopt_count = max( 0, $total_count - $opt_count );
		$opt_pct     = $total_count > 0 ? round( $opt_count / $total_count * 100 ) : 0;
		?>
		<div id="worx-media-system" class="wx-hub-wrap">
			<!-- 1. Dedicated Worx Media Hub Header -->
			<header class="wx-hub-header">
				<div class="wx-hub-brand">
					<span class="wx-hub-logo"><?php echo worx_icon( 'logo', 36 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
					<div class="wx-hub-brand-text">
						<h1><?php esc_html_e( 'Media Hub', 'worx' ); ?></h1>
						<p><?php esc_html_e( 'Manage, optimize and organize your media', 'worx' ); ?></p>
					</div>
				</div>

				<div class="wx-hub-search-box">
					<span class="wx-search-icon"><?php echo worx_icon( 'search', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
					<input type="search" id="wx-hub-search-input" placeholder="<?php esc_attr_e( 'Search your media...', 'worx' ); ?>" autocomplete="off">
					<button type="button" id="wx-hub-search-clear" class="wx-clear-btn" style="display:none;" aria-label="<?php esc_attr_e( 'Clear search', 'worx' ); ?>">&times;</button>
				</div>

				<div class="wx-hub-actions">
					<div class="wx-view-switcher" role="group" aria-label="<?php esc_attr_e( 'View Mode', 'worx' ); ?>">
						<button type="button" class="wx-view-btn is-active" data-mode="grid" title="<?php esc_attr_e( 'Grid view', 'worx' ); ?>">
							<?php echo worx_icon( 'grid', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						</button>
						<button type="button" class="wx-view-btn" data-mode="list" title="<?php esc_attr_e( 'List view', 'worx' ); ?>">
							<?php echo worx_icon( 'list', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						</button>
					</div>

					<button type="button" class="wx-btn wx-btn-upload" id="wx-hub-open-upload">
						<?php echo worx_icon( 'upload', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<span><?php esc_html_e( 'Upload Media', 'worx' ); ?></span>
					</button>
				</div>
			</header>

			<!-- 2. Hub Stats Bar -->
			<div class="wx-hub-stats-strip">
				<div class="wx-stat-item">
					<span class="wx-stat-label"><?php esc_html_e( 'Total Media', 'worx' ); ?></span>
					<strong class="wx-stat-val" id="wx-stat-total"><?php echo esc_html( number_format_i18n( $total_count ) ); ?></strong>
				</div>
				<div class="wx-stat-divider"></div>
				<div class="wx-stat-item">
					<span class="wx-stat-label"><?php esc_html_e( 'Optimized with Worx', 'worx' ); ?></span>
					<strong class="wx-stat-val wx-stat-ok" id="wx-stat-opt"><?php echo esc_html( number_format_i18n( $opt_count ) ); ?> (<?php echo esc_html( $opt_pct ); ?>%)</strong>
				</div>
				<div class="wx-stat-divider"></div>
				<div class="wx-stat-item">
					<span class="wx-stat-label"><?php esc_html_e( 'Unoptimized Legacy', 'worx' ); ?></span>
					<strong class="wx-stat-val wx-stat-warn" id="wx-stat-unopt"><?php echo esc_html( number_format_i18n( $unopt_count ) ); ?></strong>
				</div>

				<?php if ( $unopt_count > 0 ) : ?>
					<button type="button" class="wx-btn wx-btn-sm wx-btn-bulk-opt" id="wx-hub-start-bulk-btn">
						<?php echo worx_icon( 'bolt', 14 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<span><?php echo esc_html( sprintf( __( 'Bulk Optimize (%d)', 'worx' ), $unopt_count ) ); ?></span>
					</button>
				<?php endif; ?>

				<a href="<?php echo esc_url( admin_url( 'admin.php?page=' . Worx_Wizard::PAGE ) ); ?>" class="wx-hub-config-link">
					<?php echo worx_icon( 'settings', 14 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					<span><?php esc_html_e( 'Settings', 'worx' ); ?></span>
				</a>
			</div>

			<!-- 3. Category Filters & Sorting Toolbar -->
			<div class="wx-hub-toolbar">
				<div class="wx-filter-chips" role="tablist" aria-label="<?php esc_attr_e( 'Media Filters', 'worx' ); ?>">
					<button type="button" class="wx-chip is-active" data-filter="all"><?php esc_html_e( 'All', 'worx' ); ?></button>
					<button type="button" class="wx-chip" data-filter="images"><?php esc_html_e( 'Images', 'worx' ); ?></button>
					<button type="button" class="wx-chip" data-filter="webp"><?php esc_html_e( 'WebP', 'worx' ); ?></button>
					<button type="button" class="wx-chip" data-filter="optimized"><?php esc_html_e( 'Optimized', 'worx' ); ?></button>
					<button type="button" class="wx-chip" data-filter="pending_wm"><?php esc_html_e( 'Pending Watermark', 'worx' ); ?></button>
					<button type="button" class="wx-chip" data-filter="videos"><?php esc_html_e( 'Videos', 'worx' ); ?></button>
					<button type="button" class="wx-chip" data-filter="documents"><?php esc_html_e( 'Documents', 'worx' ); ?></button>
				</div>

				<div class="wx-sort-box">
					<label for="wx-hub-sort" class="screen-reader-text"><?php esc_html_e( 'Sort by', 'worx' ); ?></label>
					<select id="wx-hub-sort">
						<option value="newest"><?php esc_html_e( 'Newest First', 'worx' ); ?></option>
						<option value="oldest"><?php esc_html_e( 'Oldest First', 'worx' ); ?></option>
						<option value="largest"><?php esc_html_e( 'Largest Size', 'worx' ); ?></option>
						<option value="smallest"><?php esc_html_e( 'Smallest Size', 'worx' ); ?></option>
						<option value="name"><?php esc_html_e( 'Name A-Z', 'worx' ); ?></option>
					</select>
				</div>
			</div>

			<!-- 4. Media Grid / Workspace -->
			<div class="wx-hub-main">
				<div class="wx-hub-content">
					<!-- Active media grid container -->
					<div id="wx-hub-grid" class="wx-media-grid" aria-live="polite">
						<!-- Dynamically populated via AJAX -->
						<div class="wx-hub-loading">
							<span class="wx-hub-spinner"></span>
							<span><?php esc_html_e( 'Loading Worx Media Hub...', 'worx' ); ?></span>
						</div>
					</div>

					<!-- Empty State (No generic icons; uses official Worx branding) -->
					<div id="wx-hub-empty" class="wx-hub-empty-state" style="display:none;">
						<div class="wx-empty-logo">
							<?php echo worx_icon( 'logo', 56 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						</div>
						<h2><?php esc_html_e( 'Your Media Hub is empty', 'worx' ); ?></h2>
						<p><?php esc_html_e( 'Upload your first file and let Worx optimize it automatically.', 'worx' ); ?></p>
						<button type="button" class="wx-btn wx-btn-upload wx-btn-empty-upload">
							<?php echo worx_icon( 'upload', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
							<span><?php esc_html_e( 'Upload Media', 'worx' ); ?></span>
						</button>
					</div>
				</div>

				<!-- 5. Media Inspector / Details Drawer (Right-side slide panel) -->
				<aside id="wx-hub-inspector" class="wx-hub-inspector" style="display:none;" aria-label="<?php esc_attr_e( 'Media Inspector', 'worx' ); ?>">
					<div class="wx-inspector-head">
						<h4><?php esc_html_e( 'Media Details', 'worx' ); ?></h4>
						<button type="button" class="wx-inspector-close" aria-label="<?php esc_attr_e( 'Close Inspector', 'worx' ); ?>">&times;</button>
					</div>

					<div class="wx-inspector-body">
						<div class="wx-inspector-preview" id="wx-insp-preview"></div>

						<div class="wx-inspector-meta">
							<div class="wx-insp-row">
								<span class="wx-insp-key"><?php esc_html_e( 'Filename', 'worx' ); ?></span>
								<span class="wx-insp-val" id="wx-insp-name">-</span>
							</div>
							<div class="wx-insp-row">
								<span class="wx-insp-key"><?php esc_html_e( 'Format', 'worx' ); ?></span>
								<span class="wx-insp-val" id="wx-insp-format">-</span>
							</div>
							<div class="wx-insp-row">
								<span class="wx-insp-key"><?php esc_html_e( 'Dimensions', 'worx' ); ?></span>
								<span class="wx-insp-val" id="wx-insp-dim">-</span>
							</div>
							<div class="wx-insp-row">
								<span class="wx-insp-key"><?php esc_html_e( 'Date', 'worx' ); ?></span>
								<span class="wx-insp-val" id="wx-insp-date">-</span>
							</div>
						</div>

						<!-- Optimization Visualization -->
						<div class="wx-inspector-opt-box" id="wx-insp-opt-box">
							<h5><?php esc_html_e( 'Optimization Analysis', 'worx' ); ?></h5>
							<div class="wx-opt-flow">
								<div class="wx-opt-node">
									<span class="wx-opt-label"><?php esc_html_e( 'Original', 'worx' ); ?></span>
									<strong class="wx-opt-size" id="wx-insp-orig-size">-</strong>
								</div>
								<div class="wx-opt-arrow">
									<span>────────→</span>
									<span class="wx-opt-pct-badge" id="wx-insp-savings-badge">0%</span>
								</div>
								<div class="wx-opt-node">
									<span class="wx-opt-label">WebP</span>
									<strong class="wx-opt-size wx-opt-size-green" id="wx-insp-opt-size">-</strong>
								</div>
							</div>
							<p class="wx-opt-summary" id="wx-insp-opt-summary"></p>
						</div>

						<div class="wx-inspector-actions">
							<button type="button" class="wx-btn wx-btn-block wx-btn-ghost" id="wx-insp-btn-custom-wm">
								<?php echo worx_icon( 'image', 14 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
								<span><?php esc_html_e( 'Adjust Watermark', 'worx' ); ?></span>
							</button>
							<button type="button" class="wx-btn wx-btn-block wx-btn-ghost" id="wx-insp-btn-reprocess">
								<?php echo worx_icon( 'refresh', 14 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
								<span><?php esc_html_e( 'Reprocess', 'worx' ); ?></span>
							</button>
							<a href="#" class="wx-btn wx-btn-block wx-btn-ghost" id="wx-insp-btn-download" download>
								<?php echo worx_icon( 'download', 14 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
								<span><?php esc_html_e( 'Download', 'worx' ); ?></span>
							</a>
							<button type="button" class="wx-btn wx-btn-block wx-btn-danger" id="wx-insp-btn-delete">
								<?php echo worx_icon( 'trash', 14 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
								<span><?php esc_html_e( 'Delete Permanently', 'worx' ); ?></span>
							</button>
						</div>
					</div>
				</aside>
			</div>

			<!-- 6. Floating Bulk Action Bar -->
			<div id="wx-hub-bulk-bar" class="wx-floating-bulk-bar" style="display:none;">
				<div class="wx-bulk-info">
					<span id="wx-bulk-selected-count">0</span> <?php esc_html_e( 'selected', 'worx' ); ?>
				</div>
				<div class="wx-bulk-btns">
					<button type="button" class="wx-btn wx-btn-sm wx-btn-ghost" id="wx-bulk-action-optimize">
						<?php echo worx_icon( 'compress', 14 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<span><?php esc_html_e( 'Optimize', 'worx' ); ?></span>
					</button>
					<button type="button" class="wx-btn wx-btn-sm wx-btn-danger" id="wx-bulk-action-delete">
						<?php echo worx_icon( 'trash', 14 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<span><?php esc_html_e( 'Delete', 'worx' ); ?></span>
					</button>
					<button type="button" class="wx-btn wx-btn-sm wx-btn-subtle" id="wx-bulk-action-deselect">
						<span><?php esc_html_e( 'Deselect', 'worx' ); ?></span>
					</button>
				</div>
			</div>

			<!-- 7. Upload Workspace Modal -->
			<div id="wx-upload-modal" class="wx-modal-backdrop" style="display:none;" role="dialog" aria-modal="true">
				<div class="wx-modal-box wx-modal-upload-box">
					<header class="wx-modal-header">
						<div class="wx-modal-title-group">
							<span class="wx-modal-logo"><?php echo worx_icon( 'logo', 26 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
							<div>
								<h3><?php esc_html_e( 'Upload Media', 'worx' ); ?></h3>
								<p class="wx-modal-subtitle"><?php esc_html_e( 'Add and optimize your files automatically', 'worx' ); ?></p>
							</div>
						</div>
						<button type="button" class="wx-modal-close" aria-label="<?php esc_attr_e( 'Close', 'worx' ); ?>">&times;</button>
					</header>

					<div class="wx-modal-body">
						<div class="wx-upload-dropzone" id="wx-upload-dropzone">
							<div class="wx-dropzone-inner">
								<span class="wx-dropzone-icon"><?php echo worx_icon( 'logo', 48 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
								<h4><?php esc_html_e( 'Drop files here', 'worx' ); ?></h4>
								<p><?php esc_html_e( 'or browse from your computer', 'worx' ); ?></p>
								<label class="wx-btn wx-btn-primary wx-browse-label">
									<span><?php esc_html_e( 'Browse Files', 'worx' ); ?></span>
									<input type="file" id="wx-file-input" multiple style="display:none;" accept="image/*,video/*,application/*">
								</label>
								<span class="wx-dropzone-formats"><?php esc_html_e( 'Supported: JPG • PNG • WebP • GIF • SVG • MP4', 'worx' ); ?></span>
							</div>
						</div>

						<!-- Upload Queue List -->
						<div class="wx-upload-queue" id="wx-upload-queue" style="display:none;">
							<h5><?php esc_html_e( 'Upload Queue', 'worx' ); ?></h5>
							<div class="wx-queue-items" id="wx-queue-items"></div>
						</div>
					</div>

					<footer class="wx-modal-footer">
						<button type="button" class="wx-btn wx-btn-ghost wx-modal-cancel"><?php esc_html_e( 'Done', 'worx' ); ?></button>
					</footer>
				</div>
			</div>
		</div>
		<?php
	}

	/**
	 * Render standard Media Library columns (preserved for backward compatibility).
	 *
	 * @param array $cols Columns.
	 * @return array
	 */
	public function add_column( $cols ) {
		$new = array();
		foreach ( (array) $cols as $key => $label ) {
			$new[ $key ] = $label;
			if ( 'title' === $key ) {
				$new['worx'] = worx_icon( 'water_drop', 14 ) . ' ' . __( 'Worx', 'worx' );
			}
		}
		return $new;
	}

	/**
	 * Render one row of the Worx column in list mode.
	 *
	 * @param string $column_name Column key.
	 * @param int    $post_id     Attachment id.
	 * @param bool   $echo        Echo output.
	 * @return string|void
	 */
	public function render_column( $column_name, $post_id, $echo = true ) {
		if ( 'worx' !== $column_name ) {
			return $echo ? null : '';
		}

		ob_start();
		$is_image = wp_attachment_is_image( $post_id );
		?>
		<div class="wx-hub-cell" data-post-id="<?php echo (int) $post_id; ?>">
			<?php if ( ! $is_image ) : ?>
				<span class="wx-hub-muted">-</span>
			<?php else : ?>
				<?php
				$meta         = get_post_meta( $post_id, Worx_Optimizer::META_KEY, true );
				$needs_manual = get_post_meta( $post_id, Worx_Optimizer::PENDING_WM_FLAG, true );

				if ( ! empty( $needs_manual ) ) :
					?>
					<span class="wx-badge wx-badge-pending" title="<?php esc_attr_e( 'Waiting for manual watermark confirmation', 'worx' ); ?>">
						<?php echo worx_icon( 'info', 11 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<?php esc_html_e( 'Pending Watermark', 'worx' ); ?>
					</span>
				<?php elseif ( is_array( $meta ) && ! empty( $meta['is_webp'] ) ) : ?>
					<span class="wx-badge wx-badge-save" title="<?php esc_attr_e( 'Space saved by Worx', 'worx' ); ?>">
						<?php echo worx_icon( 'compress', 12 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<?php echo esc_html( number_format_i18n( (float) $meta['savings_percent'], 1 ) ); ?>%
					</span>
					<span class="wx-badge wx-badge-webp">WebP</span>
					<?php if ( ! empty( $meta['watermarked'] ) ) : ?>
						<span class="wx-badge wx-badge-wm">
							<?php echo worx_icon( 'water_drop', 11 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
							WM
						</span>
					<?php endif; ?>
				<?php else : ?>
					<span class="wx-badge wx-badge-none"><?php esc_html_e( 'Not optimized', 'worx' ); ?></span>
				<?php endif; ?>

				<div class="wx-hub-btn-group">
					<button type="button" class="button button-small wx-hub-custom-wm" data-worx-custom-wm="<?php echo (int) $post_id; ?>" title="<?php esc_attr_e( 'Manually adjust watermark for this image', 'worx' ); ?>">
						<?php echo worx_icon( 'image', 12 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<span><?php esc_html_e( 'Custom WM', 'worx' ); ?></span>
					</button>

					<button type="button" class="button button-small wx-hub-reprocess" data-worx-reprocess="<?php echo (int) $post_id; ?>" title="<?php esc_attr_e( 'Reprocess', 'worx' ); ?>">
						<?php echo worx_icon( 'refresh', 12 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					</button>
				</div>

				<span class="wx-hub-status" aria-live="polite"></span>
			<?php endif; ?>
		</div>
		<?php
		$html = ob_get_clean();

		if ( $echo ) {
			echo $html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		} else {
			return $html;
		}
	}

	/**
	 * Accent row class for list view.
	 *
	 * @param array $classes Row classes.
	 * @param int   $post    Post id.
	 * @return array
	 */
	public function row_classes( $classes, $post ) {
		$id = is_object( $post ) && isset( $post->ID ) ? (int) $post->ID : (int) $post;
		if ( $id && 'attachment' === get_post_type( $id ) && get_post_meta( $id, Worx_Optimizer::META_KEY, true ) ) {
			$classes[] = 'wx-webp-row';
		}
		return $classes;
	}

	/**
	 * Compact stat strip for default upload.php screen.
	 *
	 * @return void
	 */
	public function render_stats_bar() {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || 'upload' !== $screen->id ) {
			return;
		}
		if ( ! current_user_can( 'upload_files' ) ) {
			return;
		}
		?>
		<div class="wx-hub-top-banner">
			<span class="wx-banner-logo"><?php echo worx_icon( 'logo', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
			<span class="wx-banner-title"><strong><?php esc_html_e( 'Worx Media System Active', 'worx' ); ?></strong> &mdash; <?php esc_html_e( 'Manage and optimize your media with the modern high-performance workspace.', 'worx' ); ?></span>
			<a href="<?php echo esc_url( admin_url( 'upload.php?page=' . self::PAGE ) ); ?>" class="button button-primary wx-btn-open-hub">
				<?php echo worx_icon( 'bolt', 14 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<span><?php esc_html_e( 'Open Worx Media Hub', 'worx' ); ?></span>
			</a>
		</div>
		<?php
	}

	/**
	 * Banner displayed in media-new.php.
	 *
	 * @return void
	 */
	public function render_uploader_badge() {
		$is_fa = function_exists( 'get_user_locale' ) && 0 === strpos( get_user_locale(), 'fa' );
		$msg   = $is_fa
			? 'خط لوله هوشمند Worx فعال است: بهینه‌سازی WebP بدون افت کیفیت و واترمارک خودکار'
			: __( 'Worx Smart Pipeline Active: Zero-lag WebP conversion & smart watermark applied automatically', 'worx' );
		?>
		<div class="wx-uploader-badge">
			<?php echo worx_icon( 'logo', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<span><?php echo esc_html( $msg ); ?></span>
		</div>
		<?php
	}

	/**
	 * Render Modals in Admin Footer (Custom Watermark + Bulk Optimizer).
	 *
	 * @return void
	 */
	public function render_modals() {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || ( 'upload' !== $screen->id && 'media-new' !== $screen->id && false === strpos( $screen->id, self::PAGE ) ) ) {
			return;
		}
		if ( ! current_user_can( 'upload_files' ) ) {
			return;
		}

		$def_wm_src = WORX_PLUGIN_URL . 'assets/img/wx-watermark.png';
		if ( ! empty( $this->settings['watermark_custom_id'] ) ) {
			$u = wp_get_attachment_image_url( $this->settings['watermark_custom_id'], 'full' );
			if ( $u ) {
				$def_wm_src = $u;
			}
		}
		?>
		<!-- Modal 1: Custom Watermark Editor for Single Image -->
		<div id="wx-custom-wm-modal" class="wx-modal-backdrop" style="display:none;" role="dialog" aria-modal="true">
			<div class="wx-modal-box">
				<header class="wx-modal-header">
					<h3><?php echo worx_icon( 'image', 18 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> <span><?php esc_html_e( 'Adjust Watermark for Image', 'worx' ); ?></span></h3>
					<button type="button" class="wx-modal-close" aria-label="<?php esc_attr_e( 'Close', 'worx' ); ?>">&times;</button>
				</header>

				<div class="wx-modal-body">
					<div class="wx-modal-stage-wrap">
						<div class="wx-modal-stage" id="wx-modal-stage">
							<img id="wx-modal-stage-img" src="" alt="">
							<img id="wx-modal-wm" src="<?php echo esc_url( $def_wm_src ); ?>" alt="" style="display:none;">
							<span class="wx-drag-hint"><?php esc_html_e( 'Drag to position watermark freely', 'worx' ); ?></span>
						</div>
					</div>

					<div class="wx-modal-controls">
						<div class="wx-modal-field wx-switch-row">
							<label class="wx-switch">
								<input type="checkbox" id="wx-modal-wm-enable" checked>
								<span class="wx-slider"></span>
							</label>
							<span class="wx-switch-text"><?php esc_html_e( 'Enable watermark on this image', 'worx' ); ?></span>
						</div>

						<div class="wx-modal-field">
							<label for="wx-modal-size"><?php esc_html_e( 'Watermark size', 'worx' ); ?> <output id="wx-modal-size-out">25%</output></label>
							<input type="range" id="wx-modal-size" min="10" max="70" step="5" value="25">
						</div>

						<div class="wx-modal-field">
							<label for="wx-modal-opacity"><?php esc_html_e( 'Watermark opacity', 'worx' ); ?> <output id="wx-modal-opacity-out">85%</output></label>
							<input type="range" id="wx-modal-opacity" min="10" max="100" step="5" value="85">
						</div>

						<div class="wx-modal-field">
							<span class="wx-pos-label"><?php esc_html_e( 'Snap to anchor', 'worx' ); ?></span>
							<div class="wx-pos-grid" id="wx-modal-grid">
								<?php foreach ( Worx_Wizard::PREVIEW_POSITIONS as $code => $xy ) : ?>
									<button type="button" class="wx-pos-btn" data-pos="<?php echo esc_attr( $code ); ?>" data-x="<?php echo (int) $xy[0]; ?>" data-y="<?php echo (int) $xy[1]; ?>">
										<span class="wx-dot"></span>
									</button>
								<?php endforeach; ?>
							</div>
						</div>

						<input type="hidden" id="wx-modal-x" value="90">
						<input type="hidden" id="wx-modal-y" value="90">
						<input type="hidden" id="wx-modal-pos" value="pos-br">
						<input type="hidden" id="wx-modal-post-id" value="0">
					</div>
				</div>

				<footer class="wx-modal-footer">
					<button type="button" class="button button-primary button-hero wx-btn-save-custom" id="wx-modal-save">
						<?php echo worx_icon( 'check', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<span><?php esc_html_e( 'Apply & Reprocess Image', 'worx' ); ?></span>
					</button>
					<button type="button" class="button wx-modal-cancel"><?php esc_html_e( 'Cancel', 'worx' ); ?></button>
				</footer>
			</div>
		</div>

		<!-- Modal 2: Bulk Image Optimizer -->
		<div id="wx-bulk-modal" class="wx-modal-backdrop" style="display:none;" role="dialog" aria-modal="true">
			<div class="wx-modal-box wx-modal-bulk-box">
				<header class="wx-modal-header">
					<h3><?php echo worx_icon( 'bolt', 18 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?> <span><?php esc_html_e( 'Bulk Image Optimizer', 'worx' ); ?></span></h3>
					<button type="button" class="wx-modal-close" aria-label="<?php esc_attr_e( 'Close', 'worx' ); ?>">&times;</button>
				</header>

				<div class="wx-modal-body">
					<p class="wx-bulk-intro">
						<?php esc_html_e( 'Convert and optimize existing legacy JPEG/PNG images to high-performance WebP with smart watermarking.', 'worx' ); ?>
					</p>

					<div class="wx-bulk-progress-wrap">
						<div class="wx-bulk-progress-bar">
							<div class="wx-bulk-progress-fill" id="wx-bulk-fill" style="width: 0%;"></div>
						</div>
						<div class="wx-bulk-status-row">
							<span id="wx-bulk-count-text"><?php esc_html_e( 'Ready to start...', 'worx' ); ?></span>
							<span id="wx-bulk-pct">0%</span>
						</div>
					</div>

					<div class="wx-bulk-log" id="wx-bulk-log"></div>
				</div>

				<footer class="wx-modal-footer">
					<button type="button" class="button button-primary button-hero" id="wx-bulk-start-btn">
						<?php echo worx_icon( 'bolt', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<span><?php esc_html_e( 'Start Bulk Optimization', 'worx' ); ?></span>
					</button>
					<button type="button" class="button wx-modal-cancel" id="wx-bulk-close-btn"><?php esc_html_e( 'Close', 'worx' ); ?></button>
				</footer>
			</div>
		</div>
		<?php
	}

	/**
	 * Enqueue assets on media screens.
	 *
	 * @param string $hook Current admin page hook suffix.
	 * @return void
	 */
	public function enqueue_assets( $hook ) {
		if ( 'upload.php' !== $hook && 'media-new.php' !== $hook && false === strpos( $hook, self::PAGE ) ) {
			return;
		}
		if ( ! current_user_can( 'upload_files' ) ) {
			return;
		}
		$this->register_hub_scripts();
	}

	/**
	 * Enqueue assets when WordPress media modal is initialized.
	 *
	 * @return void
	 */
	public function enqueue_media_modal_assets() {
		if ( ! current_user_can( 'upload_files' ) ) {
			return;
		}
		$this->register_hub_scripts();
	}

	/**
	 * Common script registration and enqueue.
	 *
	 * @return void
	 */
	private function register_hub_scripts() {
		wp_enqueue_style( 'worx-hub', WORX_PLUGIN_URL . 'assets/css/media-hub.css', array(), WORX_VERSION );
		wp_enqueue_script( 'worx-hub', WORX_PLUGIN_URL . 'assets/js/media-hub.js', array(), WORX_VERSION, true );

		$wm_src = WORX_PLUGIN_URL . 'assets/img/wx-watermark.png';
		if ( ! empty( $this->settings['watermark_custom_id'] ) ) {
			$u = wp_get_attachment_image_url( $this->settings['watermark_custom_id'], 'full' );
			if ( $u ) {
				$wm_src = $u;
			}
		}

		wp_localize_script(
			'worx-hub',
			'worxHub',
			array(
				'ajaxUrl'    => admin_url( 'admin-ajax.php' ),
				'nonce'      => wp_create_nonce( self::NONCE_ACTION ),
				'defaultWm'  => $wm_src,
				'logoSvg'    => worx_icon( 'logo', 16 ),
				'uploadMode' => isset( $this->settings['watermark_upload_mode'] ) ? $this->settings['watermark_upload_mode'] : 'auto',
				'isHubPage'  => isset( $_GET['page'] ) && self::PAGE === $_GET['page'], // phpcs:ignore WordPress.Security.NonceVerification.Recommended
				'i18n'       => array(
					'working'       => __( 'Processing...', 'worx' ),
					'done'          => __( 'Done', 'worx' ),
					'error'         => __( 'Error', 'worx' ),
					'saved'         => __( 'Watermark saved and image reprocessed!', 'worx' ),
					'bulkComplete'  => __( 'Bulk optimization complete!', 'worx' ),
					'optimizing'    => __( 'Optimizing image %1$d of %2$d...', 'worx' ),
					'customWmBtn'   => __( 'Adjust Watermark', 'worx' ),
					'confirmDelete' => __( 'Are you sure you want to permanently delete this media file?', 'worx' ),
					'confirmBulk'   => __( 'Are you sure you want to delete the selected items?', 'worx' ),
				),
			)
		);
	}

	/**
	 * AJAX: fetch paginated, searchable, filterable media items for the Worx Media Hub.
	 */
	public function ajax_get_hub_media() {
		check_ajax_referer( self::NONCE_ACTION, 'nonce' );
		if ( ! current_user_can( 'upload_files' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'worx' ) ), 403 );
		}

		$search = isset( $_POST['search'] ) ? sanitize_text_field( wp_unslash( $_POST['search'] ) ) : '';
		$filter = isset( $_POST['filter'] ) ? sanitize_text_field( wp_unslash( $_POST['filter'] ) ) : 'all';
		$sort   = isset( $_POST['sort'] ) ? sanitize_text_field( wp_unslash( $_POST['sort'] ) ) : 'newest';
		$paged  = isset( $_POST['paged'] ) ? max( 1, absint( $_POST['paged'] ) ) : 1;

		$args = array(
			'post_type'      => 'attachment',
			'post_status'    => 'inherit',
			'posts_per_page' => 48,
			'paged'          => $paged,
		);

		if ( '' !== $search ) {
			$args['s'] = $search;
		}

		// Filter criteria
		switch ( $filter ) {
			case 'images':
				$args['post_mime_type'] = 'image/*';
				break;
			case 'videos':
				$args['post_mime_type'] = 'video/*';
				break;
			case 'documents':
				$args['post_mime_type'] = array( 'application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'text/plain' );
				break;
			case 'webp':
				$args['post_mime_type'] = 'image/webp';
				break;
			case 'optimized':
				$args['meta_query'] = array(
					array(
						'key'     => Worx_Optimizer::META_KEY,
						'compare' => 'EXISTS',
					),
				);
				break;
			case 'pending_wm':
				$args['meta_query'] = array(
					array(
						'key'   => Worx_Optimizer::PENDING_WM_FLAG,
						'value' => '1',
					),
				);
				break;
		}

		// Sort criteria
		switch ( $sort ) {
			case 'oldest':
				$args['orderby'] = 'date';
				$args['order']   = 'ASC';
				break;
			case 'name':
				$args['orderby'] = 'title';
				$args['order']   = 'ASC';
				break;
			case 'newest':
			default:
				$args['orderby'] = 'date';
				$args['order']   = 'DESC';
				break;
		}

		$query = new WP_Query( $args );
		$items = array();

		foreach ( $query->posts as $post ) {
			$id       = (int) $post->ID;
			$mime     = (string) $post->post_mime_type;
			$file     = get_attached_file( $id );
			$ext      = $file ? strtolower( pathinfo( $file, PATHINFO_EXTENSION ) ) : '';
			$filesize = ( $file && file_exists( $file ) ) ? (int) filesize( $file ) : 0;
			$meta     = get_post_meta( $id, Worx_Optimizer::META_KEY, true );
			$is_img   = wp_attachment_is_image( $id );

			$url   = wp_get_attachment_url( $id );
			$thumb = $url;
			if ( $is_img ) {
				$thumb_url = wp_get_attachment_image_url( $id, 'medium' );
				if ( $thumb_url ) {
					$thumb = $thumb_url;
				}
			}

			$img_meta = wp_get_attachment_metadata( $id );
			$dim      = '';
			if ( is_array( $img_meta ) && ! empty( $img_meta['width'] ) && ! empty( $img_meta['height'] ) ) {
				$dim = $img_meta['width'] . ' × ' . $img_meta['height'];
			}

			$is_optimized = is_array( $meta ) && ! empty( $meta['is_webp'] );
			$savings      = $is_optimized ? (float) $meta['savings_percent'] : 0;
			$orig_size    = ( is_array( $meta ) && ! empty( $meta['original_size'] ) ) ? (int) $meta['original_size'] : $filesize;

			$items[] = array(
				'id'              => $id,
				'title'           => $post->post_title ? $post->post_title : ( $file ? basename( $file ) : 'Media #' . $id ),
				'filename'        => $file ? basename( $file ) : '',
				'ext'             => strtoupper( $ext ),
				'mime'            => $mime,
				'size'            => $filesize,
				'size_formatted'  => self::format_bytes( $filesize ),
				'orig_size_fmt'   => self::format_bytes( $orig_size ),
				'dimensions'      => $dim,
				'url'             => $url,
				'thumb'           => $thumb,
				'is_image'        => $is_img,
				'is_webp'         => ( 'image/webp' === $mime || 'webp' === $ext ),
				'is_optimized'    => $is_optimized,
				'savings_percent' => $savings,
				'watermarked'     => ( is_array( $meta ) && ! empty( $meta['watermarked'] ) ),
				'needs_manual_wm' => ! empty( get_post_meta( $id, Worx_Optimizer::PENDING_WM_FLAG, true ) ),
				'date'            => get_the_date( 'Y-m-d', $id ),
				'type_badge'      => worx_type_badge( $mime, $ext ),
			);
		}

		wp_send_json_success(
			array(
				'items'       => $items,
				'total'       => (int) $query->found_posts,
				'max_pages'   => (int) $query->max_num_pages,
				'current_page' => $paged,
			)
		);
	}

	/**
	 * AJAX: Direct file upload via Worx Media Hub dropzone.
	 */
	public function ajax_upload_file() {
		check_ajax_referer( self::NONCE_ACTION, 'nonce' );
		if ( ! current_user_can( 'upload_files' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'worx' ) ), 403 );
		}

		if ( empty( $_FILES['file'] ) ) {
			wp_send_json_error( array( 'message' => __( 'No file provided.', 'worx' ) ), 400 );
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';

		// wp_handle_upload automatically triggers Worx_Optimizer::process_upload
		$upload = wp_handle_upload( $_FILES['file'], array( 'test_form' => false ) );

		if ( isset( $upload['error'] ) ) {
			wp_send_json_error( array( 'message' => $upload['error'] ), 500 );
		}

		$filename = $upload['file'];
		$filetype = wp_check_filetype( basename( $filename ), null );

		$attachment = array(
			'post_mime_type' => $filetype['type'] ? $filetype['type'] : $upload['type'],
			'post_title'     => preg_replace( '/\.[^.]+$/', '', basename( $filename ) ),
			'post_content'   => '',
			'post_status'    => 'inherit',
		);

		$attach_id = wp_insert_attachment( $attachment, $filename );
		if ( ! is_wp_error( $attach_id ) ) {
			$attach_data = wp_generate_attachment_metadata( $attach_id, $filename );
			wp_update_attachment_metadata( $attach_id, $attach_data );

			// Check metadata
			$meta      = get_post_meta( $attach_id, Worx_Optimizer::META_KEY, true );
			$orig_size = ( is_array( $meta ) && ! empty( $meta['original_size'] ) ) ? (int) $meta['original_size'] : (int) filesize( $filename );
			$opt_size  = (int) filesize( $filename );
			$savings   = ( is_array( $meta ) && ! empty( $meta['savings_percent'] ) ) ? $meta['savings_percent'] : 0;

			delete_transient( 'worx_hub_stats' );

			wp_send_json_success(
				array(
					'id'             => $attach_id,
					'title'          => basename( $filename ),
					'orig_size_fmt'  => self::format_bytes( $orig_size ),
					'opt_size_fmt'   => self::format_bytes( $opt_size ),
					'savings'        => $savings,
					'is_webp'        => ( 'image/webp' === $upload['type'] ),
				)
			);
		}

		wp_send_json_error( array( 'message' => __( 'Could not register attachment.', 'worx' ) ), 500 );
	}

	/**
	 * AJAX: Delete single attachment.
	 */
	public function ajax_delete_attachment() {
		check_ajax_referer( self::NONCE_ACTION, 'nonce' );
		if ( ! current_user_can( 'delete_posts' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'worx' ) ), 403 );
		}

		$post_id = isset( $_POST['attachment_id'] ) ? absint( $_POST['attachment_id'] ) : 0;
		if ( ! $post_id ) {
			wp_send_json_error( array( 'message' => __( 'Invalid ID.', 'worx' ) ), 400 );
		}

		$res = wp_delete_attachment( $post_id, true );
		if ( $res ) {
			delete_transient( 'worx_hub_stats' );
			wp_send_json_success();
		}

		wp_send_json_error( array( 'message' => __( 'Could not delete attachment.', 'worx' ) ), 500 );
	}

	/**
	 * AJAX: Bulk delete attachments.
	 */
	public function ajax_bulk_delete() {
		check_ajax_referer( self::NONCE_ACTION, 'nonce' );
		if ( ! current_user_can( 'delete_posts' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'worx' ) ), 403 );
		}

		$ids = isset( $_POST['attachment_ids'] ) ? (array) $_POST['attachment_ids'] : array();
		foreach ( $ids as $id ) {
			wp_delete_attachment( absint( $id ), true );
		}

		delete_transient( 'worx_hub_stats' );
		wp_send_json_success();
	}

	/**
	 * AJAX: fetch image preview URL and current watermark settings for single image.
	 */
	public function ajax_get_attachment_preview() {
		check_ajax_referer( self::NONCE_ACTION, 'nonce' );
		if ( ! current_user_can( 'upload_files' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'worx' ) ), 403 );
		}

		$post_id = isset( $_POST['attachment_id'] ) ? absint( $_POST['attachment_id'] ) : 0;
		if ( ! $post_id || ! wp_attachment_is_image( $post_id ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid attachment.', 'worx' ) ), 400 );
		}

		$url = wp_get_attachment_image_url( $post_id, 'large' );
		if ( ! $url ) {
			$url = wp_get_attachment_url( $post_id );
		}

		$meta   = get_post_meta( $post_id, Worx_Optimizer::META_KEY, true );
		$custom = ( is_array( $meta ) && ! empty( $meta['custom_watermark'] ) ) ? $meta['custom_watermark'] : array();

		$data = array(
			'url'      => $url,
			'size'     => isset( $custom['watermark_size'] ) ? (int) $custom['watermark_size'] : (int) $this->settings['watermark_size'],
			'opacity'  => isset( $custom['watermark_opacity'] ) ? (int) $custom['watermark_opacity'] : (int) $this->settings['watermark_opacity'],
			'position' => isset( $custom['watermark_position'] ) ? $custom['watermark_position'] : $this->settings['watermark_position'],
			'x'        => isset( $custom['watermark_x'] ) ? (float) $custom['watermark_x'] : (float) $this->settings['watermark_x'],
			'y'        => isset( $custom['watermark_y'] ) ? (float) $custom['watermark_y'] : (float) $this->settings['watermark_y'],
			'enabled'  => isset( $custom['watermark_enabled'] ) ? ! empty( $custom['watermark_enabled'] ) : ! empty( $this->settings['watermark_enabled'] ),
		);

		wp_send_json_success( $data );
	}

	/**
	 * AJAX: save custom watermark parameters and reprocess image.
	 */
	public function ajax_save_custom_watermark() {
		check_ajax_referer( self::NONCE_ACTION, 'nonce' );
		if ( ! current_user_can( 'upload_files' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'worx' ) ), 403 );
		}

		$post_id = isset( $_POST['attachment_id'] ) ? absint( $_POST['attachment_id'] ) : 0;
		if ( ! $post_id || ! wp_attachment_is_image( $post_id ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid attachment.', 'worx' ) ), 400 );
		}

		$custom_settings = array(
			'watermark_enabled'  => ! empty( $_POST['watermark_enabled'] ),
			'watermark_position' => isset( $_POST['watermark_position'] ) ? sanitize_text_field( wp_unslash( $_POST['watermark_position'] ) ) : 'pos-br',
			'watermark_x'        => isset( $_POST['watermark_x'] ) ? max( 0, min( 100, (float) $_POST['watermark_x'] ) ) : 90,
			'watermark_y'        => isset( $_POST['watermark_y'] ) ? max( 0, min( 100, (float) $_POST['watermark_y'] ) ) : 90,
			'watermark_size'     => isset( $_POST['watermark_size'] ) ? max( 10, min( 70, (int) $_POST['watermark_size'] ) ) : 25,
			'watermark_opacity'  => isset( $_POST['watermark_opacity'] ) ? max( 10, min( 100, (int) $_POST['watermark_opacity'] ) ) : 85,
		);

		$optimizer = Worx_Core::instance()->optimizer;
		try {
			$meta = $optimizer->reprocess_attachment( $post_id, $custom_settings );
		} catch ( \Throwable $e ) {
			wp_send_json_error( array( 'message' => $e->getMessage() ), 500 );
		}

		delete_transient( 'worx_hub_stats' );

		wp_send_json_success(
			array(
				'meta' => $meta,
				'html' => $this->render_column( 'worx', $post_id, false ),
			)
		);
	}

	/**
	 * AJAX: fetch list of unoptimized attachment IDs for bulk processing.
	 */
	public function ajax_get_bulk_candidates() {
		check_ajax_referer( self::NONCE_ACTION, 'nonce' );
		if ( ! current_user_can( 'upload_files' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'worx' ) ), 403 );
		}

		$optimizer = Worx_Core::instance()->optimizer;
		$ids       = $optimizer->get_unoptimized_attachment_ids();

		wp_send_json_success( array( 'ids' => $ids ) );
	}

	/**
	 * AJAX: process single attachment during bulk loop.
	 */
	public function ajax_bulk_optimize_single() {
		check_ajax_referer( self::NONCE_ACTION, 'nonce' );
		if ( ! current_user_can( 'upload_files' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'worx' ) ), 403 );
		}

		$post_id = isset( $_POST['attachment_id'] ) ? absint( $_POST['attachment_id'] ) : 0;
		if ( ! $post_id ) {
			wp_send_json_error( array( 'message' => __( 'Invalid ID.', 'worx' ) ), 400 );
		}

		$optimizer = Worx_Core::instance()->optimizer;
		try {
			$meta = $optimizer->reprocess_attachment( $post_id );
		} catch ( \Throwable $e ) {
			wp_send_json_error( array( 'message' => $e->getMessage() ), 500 );
		}

		delete_transient( 'worx_hub_stats' );

		wp_send_json_success(
			array(
				'id'      => $post_id,
				'title'   => get_the_title( $post_id ),
				'savings' => $meta['savings_percent'],
			)
		);
	}

	/**
	 * AJAX: reprocess one attachment.
	 */
	public function ajax_reprocess() {
		check_ajax_referer( self::NONCE_ACTION, 'nonce' );

		if ( ! current_user_can( 'upload_files' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'worx' ) ), 403 );
		}

		$post_id = isset( $_POST['attachment_id'] ) ? absint( $_POST['attachment_id'] ) : 0;
		if ( ! $post_id || 'attachment' !== get_post_type( $post_id ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid attachment.', 'worx' ) ), 400 );
		}

		$optimizer = Worx_Core::instance()->optimizer;
		try {
			$meta = $optimizer->reprocess_attachment( $post_id );
		} catch ( \Throwable $e ) {
			error_log( sprintf( 'Worx: reprocess failed for %d: %s', $post_id, $e->getMessage() ) );
			wp_send_json_error( array( 'message' => $e->getMessage() ), 500 );
		}

		delete_transient( 'worx_hub_stats' );

		wp_send_json_success(
			array(
				'meta' => $meta,
				'html' => $this->render_column( 'worx', $post_id, false ),
			)
		);
	}
}
