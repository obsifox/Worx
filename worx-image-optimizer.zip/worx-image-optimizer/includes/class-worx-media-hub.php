<?php
/**
 * Worx modern media hub, bulk optimizer & per-image watermark customizer.
 *
 * Full management suite for the WordPress Media Library:
 *  - Bulk optimization of legacy/existing images with real-time progress.
 *  - Per-image manual watermark editor dialog with live drag-and-drop.
 *  - Upload mode handling (Automatic vs. Manual Confirmation).
 *  - Media cards cyberpunk theme integration with WX logo.
 *  - Per-row AJAX reprocess & stat strip with transient cache.
 *
 * @package Worx
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Worx_Media_Hub {

	const NONCE_ACTION = 'worx_media_action';

	/**
	 * Plugin settings snapshot.
	 *
	 * @var array
	 */
	private $settings;

	/**
	 * Constructor.
	 *
	 * @param array $settings Worx settings array.
	 */
	public function __construct( array $settings ) {
		$this->settings = $settings;
	}

	/**
	 * Hook wiring.
	 *
	 * @return void
	 */
	public function hooks() {
		add_filter( 'manage_media_library_columns', array( $this, 'add_column' ) );
		add_action( 'manage_media_library_custom_column', array( $this, 'render_column' ), 10, 3 );
		add_filter( 'post_row_classes', array( $this, 'row_classes' ), 10, 2 );
		add_action( 'admin_notices', array( $this, 'render_stats_bar' ) );
		add_action( 'admin_footer', array( $this, 'render_modals' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		add_action( 'wp_enqueue_media', array( $this, 'enqueue_media_modal_assets' ) );
		add_action( 'post-upload-ui', array( $this, 'render_uploader_badge' ) );

		// AJAX Endpoints
		add_action( 'wp_ajax_worx_reprocess_image', array( $this, 'ajax_reprocess' ) );
		add_action( 'wp_ajax_worx_get_bulk_candidates', array( $this, 'ajax_get_bulk_candidates' ) );
		add_action( 'wp_ajax_worx_bulk_optimize_single', array( $this, 'ajax_bulk_optimize_single' ) );
		add_action( 'wp_ajax_worx_get_attachment_preview', array( $this, 'ajax_get_attachment_preview' ) );
		add_action( 'wp_ajax_worx_save_custom_watermark', array( $this, 'ajax_save_custom_watermark' ) );
	}

	/**
	 * Insert the Worx column right after the title column.
	 *
	 * @param array $cols Existing columns.
	 * @return array
	 */
	public function add_column( $cols ) {
		$new = array();
		foreach ( (array) $cols as $key => $label ) {
			$new[ $key ] = $label;
			if ( 'title' === $key ) {
				$new['worx'] = worx_icon( 'water_drop', 14 ) . ' ' . __( 'Worx', 'worx' );
			}
		}
		return $new;
	}

	/**
	 * Render one row of the Worx column.
	 *
	 * @param string $column_name Column key.
	 * @param int    $post_id     Attachment id.
	 * @param bool   $echo        Echo instead of return (AJAX reuse).
	 * @return string|void HTML when $echo is false.
	 */
	public function render_column( $column_name, $post_id, $echo = true ) {
		if ( 'worx' !== $column_name ) {
			if ( $echo ) {
				return;
			}
			return '';
		}

		ob_start();
		$is_image = wp_attachment_is_image( $post_id );
		?>
		<div class="wx-hub-cell" data-post-id="<?php echo (int) $post_id; ?>">
			<?php if ( ! $is_image ) : ?>
				<span class="wx-hub-muted">-</span>
			<?php else : ?>
				<?php
				$meta         = get_post_meta( $post_id, Worx_Optimizer::META_KEY, true );
				$needs_manual = get_post_meta( $post_id, Worx_Optimizer::PENDING_WM_FLAG, true );

				if ( ! empty( $needs_manual ) ) :
					?>
					<span class="wx-badge wx-badge-pending" title="<?php esc_attr_e( 'Waiting for manual watermark confirmation', 'worx' ); ?>">
						<?php echo worx_icon( 'info', 11 ); ?>
						<?php esc_html_e( 'Pending Watermark', 'worx' ); ?>
					</span>
				<?php elseif ( is_array( $meta ) && ! empty( $meta['is_webp'] ) ) : ?>
					<span class="wx-badge wx-badge-save" title="<?php esc_attr_e( 'Space saved by Worx', 'worx' ); ?>">
						<?php echo worx_icon( 'compress', 12 ); ?>
						<?php echo esc_html( number_format_i18n( (float) $meta['savings_percent'], 1 ) ); ?>%
					</span>
					<span class="wx-badge wx-badge-webp">WebP</span>
					<?php if ( ! empty( $meta['watermarked'] ) ) : ?>
						<span class="wx-badge wx-badge-wm">
							<?php echo worx_icon( 'water_drop', 11 ); ?>
							WM
						</span>
					<?php endif; ?>
				<?php else : ?>
					<span class="wx-badge wx-badge-none"><?php esc_html_e( 'Not optimized', 'worx' ); ?></span>
				<?php endif; ?>

				<div class="wx-hub-btn-group">
					<button type="button" class="button button-small wx-hub-custom-wm" data-worx-custom-wm="<?php echo (int) $post_id; ?>" title="<?php esc_attr_e( 'Manually adjust watermark for this image', 'worx' ); ?>">
						<?php echo worx_icon( 'image', 12 ); ?>
						<span><?php esc_html_e( 'Custom WM', 'worx' ); ?></span>
					</button>

					<button type="button" class="button button-small wx-hub-reprocess" data-worx-reprocess="<?php echo (int) $post_id; ?>" title="<?php esc_attr_e( 'Reprocess', 'worx' ); ?>">
						<?php echo worx_icon( 'refresh', 12 ); ?>
					</button>
				</div>

				<span class="wx-hub-status" aria-live="polite"></span>
			<?php endif; ?>
		</div>
		<?php
		$html = ob_get_clean();

		if ( $echo ) {
			echo $html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		} else {
			return $html;
		}
	}

	/**
	 * Accent row for already-optimized images.
	 *
	 * @param array $classes Row classes.
	 * @param int   $post    Post id.
	 * @return array
	 */
	public function row_classes( $classes, $post ) {
		$id = is_object( $post ) && isset( $post->ID ) ? (int) $post->ID : (int) $post;
		if ( $id && 'attachment' === get_post_type( $id ) && get_post_meta( $id, Worx_Optimizer::META_KEY, true ) ) {
			$classes[] = 'wx-webp-row';
		}
		return $classes;
	}

	/**
	 * Compact stat strip on top of the media library.
	 *
	 * @return void
	 */
	public function render_stats_bar() {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || 'upload' !== $screen->id ) {
			return;
		}
		if ( ! current_user_can( 'upload_files' ) ) {
			return;
		}

		$stats = get_transient( 'worx_hub_stats' );
		if ( ! is_array( $stats ) ) {
			global $wpdb;
			$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'attachment' AND post_status = 'inherit' AND post_mime_type LIKE 'image/%'" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$opt   = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(DISTINCT p.ID) FROM {$wpdb->posts} p INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID AND pm.meta_key = %s WHERE p.post_type = 'attachment' AND p.post_status = 'inherit'", Worx_Optimizer::META_KEY ) ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
			$stats = array(
				'total'     => $total,
				'optimized' => $opt,
			);
			set_transient( 'worx_hub_stats', $stats, 5 * MINUTE_IN_SECONDS );
		}

		if ( empty( $stats['total'] ) ) {
			return;
		}

		$unoptimized = max( 0, $stats['total'] - $stats['optimized'] );
		$pct         = round( $stats['optimized'] / $stats['total'] * 100 );
		?>
		<div class="wx-hub-stats">
			<span class="wx-stats-logo"><?php echo worx_icon( 'logo', 18 ); ?></span>
			<span class="wx-stats-text">
				<?php echo esc_html( sprintf( __( '%1$d images - %2$d optimized (%3$d%%)', 'worx' ), number_format_i18n( (int) $stats['total'] ), number_format_i18n( (int) $stats['optimized'] ), $pct ) ); ?>
			</span>

			<?php if ( $unoptimized > 0 ) : ?>
				<button type="button" class="button button-primary wx-bulk-start-btn" id="wx-open-bulk-modal">
					<?php echo worx_icon( 'bolt', 14 ); ?>
					<span><?php echo esc_html( sprintf( __( 'Bulk Optimize Old Images (%d)', 'worx' ), $unoptimized ) ); ?></span>
				</button>
			<?php endif; ?>

			<a href="<?php echo esc_url( admin_url( 'admin.php?page=' . Worx_Wizard::PAGE ) ); ?>"><?php esc_html_e( 'Settings', 'worx' ); ?></a>
		</div>
		<?php
	}

	/**
	 * Banner displayed in Add New Media / uploader box.
	 *
	 * @return void
	 */
	public function render_uploader_badge() {
		$is_fa = function_exists( 'get_user_locale' ) && 0 === strpos( get_user_locale(), 'fa' );
		$msg   = $is_fa
			? 'خط لوله هوشمند Worx فعال است: بهینه‌سازی WebP بدون افت کیفیت و واترمارک خودکار'
			: __( 'Worx Smart Pipeline Active: Zero-lag WebP conversion & smart watermark applied automatically', 'worx' );
		?>
		<div class="wx-uploader-badge">
			<?php echo worx_icon( 'logo', 20 ); ?>
			<span><?php echo esc_html( $msg ); ?></span>
		</div>
		<?php
	}

	/**
	 * Render Modals in Admin Footer (Bulk Optimizer + Custom Watermark Editor).
	 *
	 * @return void
	 */
	public function render_modals() {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( ! $screen || ( 'upload' !== $screen->id && 'media-new' !== $screen->id ) ) {
			return;
		}
		if ( ! current_user_can( 'upload_files' ) ) {
			return;
		}

		$def_wm_src = WORX_PLUGIN_URL . 'assets/img/wx-watermark.png';
		if ( ! empty( $this->settings['watermark_custom_id'] ) ) {
			$u = wp_get_attachment_image_url( $this->settings['watermark_custom_id'], 'full' );
			if ( $u ) {
				$def_wm_src = $u;
			}
		}
		?>
		<!-- Modal 1: Custom Watermark Editor for Single Image -->
		<div id="wx-custom-wm-modal" class="wx-modal-backdrop" style="display:none;" role="dialog" aria-modal="true">
			<div class="wx-modal-box">
				<header class="wx-modal-header">
					<h3><?php echo worx_icon( 'image', 18 ); ?> <span><?php esc_html_e( 'Adjust Watermark for Image', 'worx' ); ?></span></h3>
					<button type="button" class="wx-modal-close" aria-label="<?php esc_attr_e( 'Close', 'worx' ); ?>">&times;</button>
				</header>

				<div class="wx-modal-body">
					<div class="wx-modal-stage-wrap">
						<div class="wx-modal-stage" id="wx-modal-stage">
							<img id="wx-modal-stage-img" src="" alt="">
							<img id="wx-modal-wm" src="<?php echo esc_url( $def_wm_src ); ?>" alt="" style="display:none;">
							<span class="wx-drag-hint"><?php esc_html_e( 'Drag to position watermark freely', 'worx' ); ?></span>
						</div>
					</div>

					<div class="wx-modal-controls">
						<div class="wx-modal-field wx-switch-row">
							<label class="wx-switch">
								<input type="checkbox" id="wx-modal-wm-enable" checked>
								<span class="wx-slider"></span>
							</label>
							<span class="wx-switch-text"><?php esc_html_e( 'Enable watermark on this image', 'worx' ); ?></span>
						</div>

						<div class="wx-modal-field">
							<label for="wx-modal-size"><?php esc_html_e( 'Watermark size', 'worx' ); ?> <output id="wx-modal-size-out">25%</output></label>
							<input type="range" id="wx-modal-size" min="10" max="70" step="5" value="25">
						</div>

						<div class="wx-modal-field">
							<label for="wx-modal-opacity"><?php esc_html_e( 'Watermark opacity', 'worx' ); ?> <output id="wx-modal-opacity-out">85%</output></label>
							<input type="range" id="wx-modal-opacity" min="10" max="100" step="5" value="85">
						</div>

						<div class="wx-modal-field">
							<span class="wx-pos-label"><?php esc_html_e( 'Snap to anchor', 'worx' ); ?></span>
							<div class="wx-pos-grid" id="wx-modal-grid">
								<?php foreach ( Worx_Wizard::PREVIEW_POSITIONS as $code => $xy ) : ?>
									<button type="button" class="wx-pos-btn" data-pos="<?php echo esc_attr( $code ); ?>" data-x="<?php echo (int) $xy[0]; ?>" data-y="<?php echo (int) $xy[1]; ?>">
										<span class="wx-dot"></span>
									</button>
								<?php endforeach; ?>
							</div>
						</div>

						<input type="hidden" id="wx-modal-x" value="90">
						<input type="hidden" id="wx-modal-y" value="90">
						<input type="hidden" id="wx-modal-pos" value="pos-br">
						<input type="hidden" id="wx-modal-post-id" value="0">
					</div>
				</div>

				<footer class="wx-modal-footer">
					<button type="button" class="button button-primary button-hero wx-btn-save-custom" id="wx-modal-save">
						<?php echo worx_icon( 'check', 16 ); ?>
						<span><?php esc_html_e( 'Apply & Reprocess Image', 'worx' ); ?></span>
					</button>
					<button type="button" class="button wx-modal-cancel"><?php esc_html_e( 'Cancel', 'worx' ); ?></button>
				</footer>
			</div>
		</div>

		<!-- Modal 2: Bulk Image Optimizer -->
		<div id="wx-bulk-modal" class="wx-modal-backdrop" style="display:none;" role="dialog" aria-modal="true">
			<div class="wx-modal-box wx-modal-bulk-box">
				<header class="wx-modal-header">
					<h3><?php echo worx_icon( 'bolt', 18 ); ?> <span><?php esc_html_e( 'Bulk Image Optimizer', 'worx' ); ?></span></h3>
					<button type="button" class="wx-modal-close" aria-label="<?php esc_attr_e( 'Close', 'worx' ); ?>">&times;</button>
				</header>

				<div class="wx-modal-body">
					<p class="wx-bulk-intro">
						<?php esc_html_e( 'Convert and optimize existing legacy JPEG/PNG images to high-performance WebP with smart watermarking.', 'worx' ); ?>
					</p>

					<div class="wx-bulk-progress-wrap">
						<div class="wx-bulk-progress-bar">
							<div class="wx-bulk-progress-fill" id="wx-bulk-fill" style="width: 0%;"></div>
						</div>
						<div class="wx-bulk-status-row">
							<span id="wx-bulk-count-text"><?php esc_html_e( 'Ready to start...', 'worx' ); ?></span>
							<span id="wx-bulk-pct">0%</span>
						</div>
					</div>

					<div class="wx-bulk-log" id="wx-bulk-log"></div>
				</div>

				<footer class="wx-modal-footer">
					<button type="button" class="button button-primary button-hero" id="wx-bulk-start-btn">
						<?php echo worx_icon( 'bolt', 16 ); ?>
						<span><?php esc_html_e( 'Start Bulk Optimization', 'worx' ); ?></span>
					</button>
					<button type="button" class="button wx-modal-cancel" id="wx-bulk-close-btn"><?php esc_html_e( 'Close', 'worx' ); ?></button>
				</footer>
			</div>
		</div>
		<?php
	}

	/**
	 * Enqueue assets on media screens.
	 *
	 * @param string $hook Current admin page hook suffix.
	 * @return void
	 */
	public function enqueue_assets( $hook ) {
		if ( 'upload.php' !== $hook && 'media-new.php' !== $hook ) {
			return;
		}
		if ( ! current_user_can( 'upload_files' ) ) {
			return;
		}
		$this->register_hub_scripts();
	}

	/**
	 * Enqueue assets when WordPress media modal is initialized.
	 *
	 * @return void
	 */
	public function enqueue_media_modal_assets() {
		if ( ! current_user_can( 'upload_files' ) ) {
			return;
		}
		$this->register_hub_scripts();
	}

	/**
	 * Common script registration and enqueue.
	 *
	 * @return void
	 */
	private function register_hub_scripts() {
		wp_enqueue_style( 'worx-hub', WORX_PLUGIN_URL . 'assets/css/media-hub.css', array(), WORX_VERSION );
		wp_enqueue_script( 'worx-hub', WORX_PLUGIN_URL . 'assets/js/media-hub.js', array(), WORX_VERSION, true );

		$wm_src = WORX_PLUGIN_URL . 'assets/img/wx-watermark.png';
		if ( ! empty( $this->settings['watermark_custom_id'] ) ) {
			$u = wp_get_attachment_image_url( $this->settings['watermark_custom_id'], 'full' );
			if ( $u ) {
				$wm_src = $u;
			}
		}

		wp_localize_script(
			'worx-hub',
			'worxHub',
			array(
				'ajaxUrl'    => admin_url( 'admin-ajax.php' ),
				'nonce'      => wp_create_nonce( self::NONCE_ACTION ),
				'defaultWm'  => $wm_src,
				'logoSvg'    => worx_icon( 'logo', 16 ),
				'uploadMode' => isset( $this->settings['watermark_upload_mode'] ) ? $this->settings['watermark_upload_mode'] : 'auto',
				'i18n'       => array(
					'working'       => __( 'Processing...', 'worx' ),
					'done'          => __( 'Done', 'worx' ),
					'error'         => __( 'Error', 'worx' ),
					'saved'         => __( 'Watermark saved and image reprocessed!', 'worx' ),
					'bulkComplete'  => __( 'Bulk optimization complete!', 'worx' ),
					'optimizing'    => __( 'Optimizing image %1$d of %2$d...', 'worx' ),
					'customWmBtn'   => __( 'Adjust Watermark', 'worx' ),
				),
			)
		);
	}

	/**
	 * AJAX: fetch image preview URL and current watermark settings for single image.
	 */
	public function ajax_get_attachment_preview() {
		check_ajax_referer( self::NONCE_ACTION, 'nonce' );
		if ( ! current_user_can( 'upload_files' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'worx' ) ), 403 );
		}

		$post_id = isset( $_POST['attachment_id'] ) ? absint( $_POST['attachment_id'] ) : 0;
		if ( ! $post_id || ! wp_attachment_is_image( $post_id ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid attachment.', 'worx' ) ), 400 );
		}

		$url  = wp_get_attachment_image_url( $post_id, 'large' );
		if ( ! $url ) {
			$url = wp_get_attachment_url( $post_id );
		}

		$meta = get_post_meta( $post_id, Worx_Optimizer::META_KEY, true );
		$custom = ( is_array( $meta ) && ! empty( $meta['custom_watermark'] ) ) ? $meta['custom_watermark'] : array();

		$data = array(
			'url'      => $url,
			'size'     => isset( $custom['watermark_size'] ) ? (int) $custom['watermark_size'] : (int) $this->settings['watermark_size'],
			'opacity'  => isset( $custom['watermark_opacity'] ) ? (int) $custom['watermark_opacity'] : (int) $this->settings['watermark_opacity'],
			'position' => isset( $custom['watermark_position'] ) ? $custom['watermark_position'] : $this->settings['watermark_position'],
			'x'        => isset( $custom['watermark_x'] ) ? (float) $custom['watermark_x'] : (float) $this->settings['watermark_x'],
			'y'        => isset( $custom['watermark_y'] ) ? (float) $custom['watermark_y'] : (float) $this->settings['watermark_y'],
			'enabled'  => isset( $custom['watermark_enabled'] ) ? ! empty( $custom['watermark_enabled'] ) : ! empty( $this->settings['watermark_enabled'] ),
		);

		wp_send_json_success( $data );
	}

	/**
	 * AJAX: save custom watermark parameters and reprocess image.
	 */
	public function ajax_save_custom_watermark() {
		check_ajax_referer( self::NONCE_ACTION, 'nonce' );
		if ( ! current_user_can( 'upload_files' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'worx' ) ), 403 );
		}

		$post_id = isset( $_POST['attachment_id'] ) ? absint( $_POST['attachment_id'] ) : 0;
		if ( ! $post_id || ! wp_attachment_is_image( $post_id ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid attachment.', 'worx' ) ), 400 );
		}

		$custom_settings = array(
			'watermark_enabled'  => ! empty( $_POST['watermark_enabled'] ),
			'watermark_position' => isset( $_POST['watermark_position'] ) ? sanitize_text_field( wp_unslash( $_POST['watermark_position'] ) ) : 'pos-br',
			'watermark_x'        => isset( $_POST['watermark_x'] ) ? max( 0, min( 100, (float) $_POST['watermark_x'] ) ) : 90,
			'watermark_y'        => isset( $_POST['watermark_y'] ) ? max( 0, min( 100, (float) $_POST['watermark_y'] ) ) : 90,
			'watermark_size'     => isset( $_POST['watermark_size'] ) ? max( 10, min( 70, (int) $_POST['watermark_size'] ) ) : 25,
			'watermark_opacity'  => isset( $_POST['watermark_opacity'] ) ? max( 10, min( 100, (int) $_POST['watermark_opacity'] ) ) : 85,
		);

		$optimizer = Worx_Core::instance()->optimizer;
		try {
			$meta = $optimizer->reprocess_attachment( $post_id, $custom_settings );
		} catch ( \Throwable $e ) {
			wp_send_json_error( array( 'message' => $e->getMessage() ), 500 );
		}

		delete_transient( 'worx_hub_stats' );

		wp_send_json_success(
			array(
				'meta' => $meta,
				'html' => $this->render_column( 'worx', $post_id, false ),
			)
		);
	}

	/**
	 * AJAX: fetch list of unoptimized attachment IDs for bulk processing.
	 */
	public function ajax_get_bulk_candidates() {
		check_ajax_referer( self::NONCE_ACTION, 'nonce' );
		if ( ! current_user_can( 'upload_files' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'worx' ) ), 403 );
		}

		$optimizer = Worx_Core::instance()->optimizer;
		$ids       = $optimizer->get_unoptimized_attachment_ids();

		wp_send_json_success( array( 'ids' => $ids ) );
	}

	/**
	 * AJAX: process single attachment during bulk loop.
	 */
	public function ajax_bulk_optimize_single() {
		check_ajax_referer( self::NONCE_ACTION, 'nonce' );
		if ( ! current_user_can( 'upload_files' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'worx' ) ), 403 );
		}

		$post_id = isset( $_POST['attachment_id'] ) ? absint( $_POST['attachment_id'] ) : 0;
		if ( ! $post_id ) {
			wp_send_json_error( array( 'message' => __( 'Invalid ID.', 'worx' ) ), 400 );
		}

		$optimizer = Worx_Core::instance()->optimizer;
		try {
			$meta = $optimizer->reprocess_attachment( $post_id );
		} catch ( \Throwable $e ) {
			wp_send_json_error( array( 'message' => $e->getMessage() ), 500 );
		}

		delete_transient( 'worx_hub_stats' );

		wp_send_json_success(
			array(
				'id'      => $post_id,
				'title'   => get_the_title( $post_id ),
				'savings' => $meta['savings_percent'],
			)
		);
	}

	/**
	 * AJAX: reprocess one attachment.
	 */
	public function ajax_reprocess() {
		check_ajax_referer( self::NONCE_ACTION, 'nonce' );

		if ( ! current_user_can( 'upload_files' ) ) {
			wp_send_json_error( array( 'message' => __( 'Permission denied.', 'worx' ) ), 403 );
		}

		$post_id = isset( $_POST['attachment_id'] ) ? absint( $_POST['attachment_id'] ) : 0;
		if ( ! $post_id || 'attachment' !== get_post_type( $post_id ) ) {
			wp_send_json_error( array( 'message' => __( 'Invalid attachment.', 'worx' ) ), 400 );
		}

		$optimizer = Worx_Core::instance()->optimizer;
		try {
			$meta = $optimizer->reprocess_attachment( $post_id );
		} catch ( \Throwable $e ) {
			error_log( sprintf( 'Worx: reprocess failed for %d: %s', $post_id, $e->getMessage() ) );
			wp_send_json_error( array( 'message' => $e->getMessage() ), 500 );
		}

		delete_transient( 'worx_hub_stats' );

		wp_send_json_success(
			array(
				'meta' => $meta,
				'html' => $this->render_column( 'worx', $post_id, false ),
			)
		);
	}
}
