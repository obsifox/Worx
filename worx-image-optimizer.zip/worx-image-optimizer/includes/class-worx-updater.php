<?php
/**
 * Worx Updater: Seamless automatic and manual updates from GitHub.
 *
 * Integrates directly with WordPress Core updater:
 *  - Checks GitHub releases for obsifox/Worx.
 *  - Injects updates into Dashboard > Updates and Plugins screen.
 *  - Provides "Check for Updates" manual trigger link.
 *  - Serves full plugin changelog and details in standard WP popup modal.
 *
 * @package Worx
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Worx_Updater {

	const GITHUB_REPO = 'obsifox/Worx';
	const TRANSIENT   = 'worx_github_update_cache';

	/**
	 * Hook into WordPress updater lifecycle.
	 *
	 * @return void
	 */
	public function hooks() {
		add_filter( 'pre_set_site_transient_update_plugins', array( $this, 'check_update' ) );
		add_filter( 'plugins_api', array( $this, 'plugin_popup' ), 20, 3 );
		add_filter( 'plugin_action_links_' . WORX_PLUGIN_BASENAME, array( $this, 'action_links' ) );
		add_filter( 'plugin_row_meta', array( $this, 'row_meta' ), 10, 2 );
		add_action( 'admin_init', array( $this, 'handle_manual_check' ) );
	}

	/**
	 * Add "Check for Updates" link to plugin actions on plugins.php.
	 *
	 * @param array $links Action links.
	 * @return array
	 */
	public function action_links( $links ) {
		$url = wp_nonce_url(
			add_query_arg( 'worx_check_update', '1', admin_url( 'plugins.php' ) ),
			'worx_check_update_nonce'
		);
		$check_text = ( function_exists( 'get_user_locale' ) && 0 === strpos( get_user_locale(), 'fa' ) )
			? 'بررسی بروزرسانی'
			: __( 'Check for updates', 'worx' );

		$links[] = '<a href="' . esc_url( $url ) . '" style="color:#7c4dff;font-weight:600;">' . esc_html( $check_text ) . '</a>';
		return $links;
	}

	/**
	 * Add extra metadata to plugin row.
	 *
	 * @param array  $meta Plugin meta links.
	 * @param string $file Plugin file name.
	 * @return array
	 */
	public function row_meta( $meta, $file ) {
		if ( WORX_PLUGIN_BASENAME === $file ) {
			$meta[] = '<span style="color:#00c49f;font-weight:600;">⚡ ' . esc_html__( 'Zero-lag WebP Engine', 'worx' ) . '</span>';
		}
		return $meta;
	}

	/**
	 * Handle manual update check button click.
	 *
	 * @return void
	 */
	public function handle_manual_check() {
		if ( empty( $_GET['worx_check_update'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return;
		}

		if ( ! current_user_can( 'update_plugins' ) ) {
			return;
		}

		check_admin_referer( 'worx_check_update_nonce' );

		delete_transient( self::TRANSIENT );
		delete_site_transient( 'update_plugins' );

		$release = $this->fetch_github_release( true );
		$is_fa   = function_exists( 'get_user_locale' ) && 0 === strpos( get_user_locale(), 'fa' );

		if ( $release && ! empty( $release['tag_name'] ) ) {
			$new_ver = ltrim( $release['tag_name'], 'v' );
			if ( version_compare( $new_ver, WORX_VERSION, '>' ) ) {
				$msg = $is_fa
					? sprintf( 'نگارش جدید Worx (%s) در دسترس است! لطفاً افزونه را بروزرسانی کنید.', $new_ver )
					: sprintf( __( 'A new version of Worx (%s) is available! You can update now.', 'worx' ), $new_ver );
				add_settings_error( 'worx_update', 'worx_update_found', $msg, 'updated' );
			} else {
				$msg = $is_fa
					? sprintf( 'شما از آخرین نگارش افزونه Worx (%s) استفاده می‌کنید.', WORX_VERSION )
					: sprintf( __( 'Worx is completely up to date (version %s).', 'worx' ), WORX_VERSION );
				add_settings_error( 'worx_update', 'worx_up_to_date', $msg, 'updated' );
			}
		} else {
			$msg = $is_fa
				? 'امکان برقراری ارتباط با مخزن GitHub وجود نداشت. لطفاً چند لحظه بعد تلاش کنید.'
				: __( 'Could not reach GitHub repository. Please try again shortly.', 'worx' );
			add_settings_error( 'worx_update', 'worx_check_failed', $msg, 'notice-warning' );
		}

		add_action( 'admin_notices', function () {
			settings_errors( 'worx_update' );
		} );
	}

	/**
	 * Fetch release information from GitHub API.
	 *
	 * @param bool $force_refresh Skip cache.
	 * @return array|null
	 */
	public function fetch_github_release( $force_refresh = false ) {
		$cached = get_transient( self::TRANSIENT );
		if ( ! $force_refresh && false !== $cached ) {
			return $cached;
		}

		$api_url = 'https://api.github.com/repos/' . self::GITHUB_REPO . '/releases/latest';

		$args = array(
			'timeout'    => 10,
			'headers'    => array(
				'Accept'     => 'application/vnd.github.v3+json',
				'User-Agent' => 'WordPress/Worx-Image-Optimizer-' . WORX_VERSION,
			),
			'sslverify'  => true,
		);

		$response = wp_remote_get( $api_url, $args );
		if ( is_wp_error( $response ) || 200 !== (int) wp_remote_retrieve_response_code( $response ) ) {
			// Cache failure for 10 minutes to avoid hammering GitHub.
			set_transient( self::TRANSIENT, null, 10 * MINUTE_IN_SECONDS );
			return null;
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( ! is_array( $body ) || empty( $body['tag_name'] ) ) {
			return null;
		}

		// Cache valid release for 6 hours.
		set_transient( self::TRANSIENT, $body, 6 * HOUR_IN_SECONDS );
		return $body;
	}

	/**
	 * Check if an update is available and inject it into WP core transient.
	 *
	 * @param object $transient Update plugins transient.
	 * @return object
	 */
	public function check_update( $transient ) {
		if ( ! is_object( $transient ) ) {
			$transient = new \stdClass();
		}

		$release = $this->fetch_github_release();
		if ( ! $release || empty( $release['tag_name'] ) ) {
			return $transient;
		}

		$remote_ver = ltrim( $release['tag_name'], 'v' );
		if ( version_compare( $remote_ver, WORX_VERSION, '>' ) ) {
			// Find zip package asset or fallback to zipball_url.
			$package_url = $release['zipball_url'];
			if ( ! empty( $release['assets'] ) && is_array( $release['assets'] ) ) {
				foreach ( $release['assets'] as $asset ) {
					if ( isset( $asset['name'] ) && 'worx-image-optimizer.zip' === $asset['name'] && ! empty( $asset['browser_download_url'] ) ) {
						$package_url = $asset['browser_download_url'];
						break;
					}
				}
			}

			$obj = (object) array(
				'id'            => 'worx',
				'slug'          => 'worx',
				'plugin'        => WORX_PLUGIN_BASENAME,
				'new_version'   => $remote_ver,
				'url'           => 'https://github.com/' . self::GITHUB_REPO,
				'package'       => $package_url,
				'icons'         => array(
					'1x' => WORX_PLUGIN_URL . 'assets/img/wx-watermark.png',
					'2x' => WORX_PLUGIN_URL . 'assets/img/wx-watermark.png',
				),
				'banners'       => array(
					'high' => WORX_PLUGIN_URL . 'docs/poster.jpg',
				),
				'tested'        => '6.7',
				'requires_php'  => '7.2',
			);

			$transient->response[ WORX_PLUGIN_BASENAME ] = $obj;
		}

		return $transient;
	}

	/**
	 * Provide modal details for the "View version details" screen.
	 *
	 * @param false|object|array $result Default result.
	 * @param string             $action Action name.
	 * @param object             $args   Query arguments.
	 * @return false|object
	 */
	public function plugin_popup( $result, $action, $args ) {
		if ( 'plugin_information' !== $action || empty( $args->slug ) || 'worx' !== $args->slug ) {
			return $result;
		}

		$release = $this->fetch_github_release();
		$version = ( $release && ! empty( $release['tag_name'] ) ) ? ltrim( $release['tag_name'], 'v' ) : WORX_VERSION;
		$body    = ( $release && ! empty( $release['body'] ) ) ? $release['body'] : 'Worx Image Optimizer & Smart Watermark updates and enhancements.';

		$info = (object) array(
			'name'          => 'Worx Image Optimizer & Smart Watermark',
			'slug'          => 'worx',
			'version'       => $version,
			'author'        => '<a href="https://github.com/obsifox">obsifox studio</a>',
			'homepage'      => 'https://github.com/' . self::GITHUB_REPO,
			'requires'      => '5.8',
			'tested'        => '6.7',
			'requires_php'  => '7.2',
			'downloaded'    => 1000,
			'last_updated'  => ( $release && ! empty( $release['published_at'] ) ) ? substr( $release['published_at'], 0, 10 ) : date( 'Y-m-d' ),
			'sections'      => array(
				'description'  => 'Zero-lag image pipeline for WordPress: true-quality WebP conversion, smart resizing, real-time drag-and-drop watermark, and modern media hub with zero frontend bloat.',
				'changelog'    => nl2br( esc_html( $body ) ),
				'installation' => 'Upload the ZIP file via WordPress Plugins screen (Plugins > Add New > Upload Plugin) and activate.',
			),
			'banners'       => array(
				'high' => WORX_PLUGIN_URL . 'docs/poster.jpg',
			),
		);

		return $info;
	}
}
