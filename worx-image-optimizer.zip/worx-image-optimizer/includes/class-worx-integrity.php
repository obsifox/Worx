<?php
/**
 * Worx Integrity & Tamper-Protection Engine.
 *
 * Ensures plugin authenticity and integrity. If any core file is modified,
 * patched, or corrupted, the plugin halts its operations gracefully:
 *  - Unhooks all filters and actions.
 *  - Prevents corrupt processing.
 *  - Displays a clean admin notification.
 *  - NEVER throws fatal errors or crashes the user's website (Fail-Safe Architecture).
 *
 * @package Worx
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Worx_Integrity {

	/**
	 * Tamper state flag.
	 *
	 * @var bool|null
	 */
	private static $tampered = null;

	/**
	 * Critical core files monitored for unauthorized modifications.
	 *
	 * @var array
	 */
	private static $monitored_files = array(
		'worx.php',
		'includes/class-worx-core.php',
		'includes/class-worx-optimizer.php',
		'includes/class-worx-watermark.php',
		'includes/class-worx-media-hub.php',
	);

	/**
	 * Verify plugin files integrity.
	 *
	 * @return bool True if intact, false if tampered.
	 */
	public static function verify() {
		if ( null !== self::$tampered ) {
			return ! self::$tampered;
		}

		// Allow test environments to bypass check if explicitly defined.
		if ( defined( 'WORX_TEST_MODE' ) && WORX_TEST_MODE ) {
			self::$tampered = false;
			return true;
		}

		$manifest_file = WORX_PLUGIN_DIR . 'includes/manifest.json';
		if ( ! file_exists( $manifest_file ) ) {
			// In development mode or before release packaging, generate or pass.
			self::$tampered = false;
			return true;
		}

		$content = @file_get_contents( $manifest_file );
		$manifest = @json_decode( $content, true );
		if ( ! is_array( $manifest ) || empty( $manifest['hashes'] ) ) {
			self::$tampered = true;
			self::register_notice();
			return false;
		}

		foreach ( $manifest['hashes'] as $rel_path => $expected_hash ) {
			$full_path = WORX_PLUGIN_DIR . $rel_path;
			if ( ! file_exists( $full_path ) ) {
				self::$tampered = true;
				self::register_notice();
				return false;
			}

			// Normalize line endings before hashing to prevent Windows/Linux checkout discrepancies.
			$file_content = @file_get_contents( $full_path );
			$normalized   = str_replace( array( "\r\n", "\r" ), "\n", $file_content );
			$actual_hash  = hash( 'sha256', $normalized );

			if ( ! hash_equals( $expected_hash, $actual_hash ) ) {
				self::$tampered = true;
				self::register_notice();
				return false;
			}
		}

		self::$tampered = false;
		return true;
	}

	/**
	 * Register fail-safe admin notice informing about tampering without breaking site.
	 *
	 * @return void
	 */
	public static function register_notice() {
		if ( ! function_exists( 'is_admin' ) || ! is_admin() ) {
			return;
		}

		if ( function_exists( 'add_action' ) ) {
			add_action( 'admin_notices', array( __CLASS__, 'render_tamper_notice' ) );
		}
	}

	/**
	 * Render the security notification in WP Admin.
	 *
	 * @return void
	 */
	public static function render_tamper_notice() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$is_fa = function_exists( 'get_user_locale' ) && 0 === strpos( get_user_locale(), 'fa' );

		$title   = $is_fa ? 'هشدار امنیتی افزونه Worx' : 'Worx Image Optimizer - Security Warning';
		$message = $is_fa
			? 'تغییر یا دستکاری غیرمجاز در کدهای اصلی افزونه شناسایی شد. فعالیت افزونه برای جلوگیری از هرگونه اختلال یا آسیب به سایت شما به صورت خودکار متوقف شده است. لطفاً افزونه را مجدداً از مخزن اصلی نصب کنید.'
			: 'Core integrity violation detected. Plugin files have been modified or corrupted. Plugin operations have been safely halted to protect your site stability. Please reinstall the authentic package.';

		?>
		<div class="notice notice-error" style="border-left-color: #ff3366; background: #fff8f8; padding: 12px 16px;">
			<p style="margin: 0 0 6px; font-weight: bold; color: #d63638; display: flex; align-items: center; gap: 8px;">
				<span class="dashicons dashicons-shield-alt" style="font-size: 20px;"></span>
				<?php echo esc_html( $title ); ?>
			</p>
			<p style="margin: 0; color: #3c434a; font-size: 13px; line-height: 1.5;">
				<?php echo esc_html( $message ); ?>
			</p>
		</div>
		<?php
	}

	/**
	 * Build manifest array from plugin directory (used during packaging).
	 *
	 * @return array
	 */
	public static function generate_manifest() {
		$hashes = array();
		foreach ( self::$monitored_files as $rel_path ) {
			$full_path = WORX_PLUGIN_DIR . $rel_path;
			if ( file_exists( $full_path ) ) {
				$file_content = @file_get_contents( $full_path );
				$normalized   = str_replace( array( "\r\n", "\r" ), "\n", $file_content );
				$hashes[ $rel_path ] = hash( 'sha256', $normalized );
			}
		}
		return array(
			'version'   => defined( 'WORX_VERSION' ) ? WORX_VERSION : '1.0.0',
			'generated' => date( 'c' ),
			'hashes'    => $hashes,
		);
	}
}
